package com.webasto.commons.sql.exception;

public class AuthorizationException  extends CoreException{

}
