package com.webasto.commons.sql.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.webasto.commons.sql.data.AbstractRelationalRepository;

import java.util.List;

/**
 * Generic DAO for most common operations on relational database.
 */
@Repository
public class RelationalRepository extends AbstractRelationalRepository {

//    @PersistenceContext
//    public void setEntityManager(final EntityManager entityManager) {
//        this.entityManager = entityManager;
//    }
}
