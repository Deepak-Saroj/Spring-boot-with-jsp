package com.webasto.commons.sql.service;


import com.webasto.commons.sql.service.RelationalRepository;

public abstract class BaseServiceImpl {

    
    protected RelationalRepository relationalRepository;
    
}
