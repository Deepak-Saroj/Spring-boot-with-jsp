package com.webasto.commons.sql.data;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.From;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.webasto.commons.sql.exception.PersistenceException;

/**
 * DAO for basic CRUD operations
 */
public abstract class AbstractRelationalRepository {

	private static final Logger LOG =  Logger.getLogger(AbstractRelationalRepository.class);
    protected EntityManager entityManager;

    private final Object [][]values = null;
    private final Object [][]condition = null ;
    
    public <T> T create(final T entity) throws PersistenceException {
        LOG.debug("create entity :: START");
        try {
            this.entityManager.persist(entity);
        } catch (final Exception pe) {
            LOG.error(pe.getCause());
           
            throw new PersistenceException(pe.getCause());
        }
        LOG.debug("create entity :: END ");
        return entity;
    }

    public <T> T find(final Object primaryKey, final Class<T> entityClass) throws PersistenceException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("find [ " + entityClass + "] :: START");
        }
        final T result;
        try {
            result = this.entityManager.find(entityClass, primaryKey);
        } catch (final javax.persistence.PersistenceException pe) {
            LOG.error(pe.getCause());
            throw new PersistenceException(pe.getCause());
        }
        if (LOG.isDebugEnabled()) {
            LOG.debug("find [ " + entityClass + "] :: END");
        }
        return result;
    }

    public <T> T find(final String queryName, final QueryParameters queryParams, final Class<T> resultClass) throws PersistenceException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("find [ " + queryName + "] :: START");
        }
        try {
            final TypedQuery<T> query = this.entityManager.createNamedQuery(queryName, resultClass);
            query.setFlushMode(FlushModeType.COMMIT);

            queryParams.fill(query);

            final T result = query.getSingleResult();
            if (LOG.isDebugEnabled()) {
                LOG.debug("find [ " + queryName + "] :: END");
            }
            return result;
        } catch (final NoResultException nre) {
            return null;
        } catch (final javax.persistence.PersistenceException pe) {
            LOG.error(pe.getCause());
            throw new PersistenceException(pe.getCause());
        }
    }

    public <T> List<T> list(final String queryName, final QueryParameters queryParams, final Class<T> resultClass) throws PersistenceException {
    	if (LOG.isDebugEnabled()) {
            LOG.debug("list [ " + queryName + "] :: START");
        }
        try {
            final TypedQuery<T> query = this.entityManager.createNamedQuery(queryName, resultClass);

            query.setFlushMode(FlushModeType.COMMIT);
            if (queryParams != null) {
                queryParams.fill(query);
            }
            final List<T> results = query.getResultList();
            if (LOG.isDebugEnabled()) {
                LOG.debug("list [ " + queryName + "] :: END");
            }
            return results;
        } catch (final javax.persistence.PersistenceException pe) {
            LOG.error(pe.getCause());
            throw new PersistenceException(pe.getCause());
        }
    }

    public <T> List<T> list(final String queryName, final QueryParameters queryParams, final int limit, final Class<T> resultClass) throws PersistenceException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("list [ " + queryName + "] :: START");
        }
        try {
            final TypedQuery<T> query = this.entityManager.createNamedQuery(queryName, resultClass);
            queryParams.fill(query);

            query.setMaxResults(limit);
            query.setFlushMode(FlushModeType.COMMIT);

            final List<T> results = query.getResultList();

            if (LOG.isDebugEnabled()) {
                LOG.debug("list [ " + queryName + "] :: END");
            }
            return results;
        } catch (final javax.persistence.PersistenceException pe) {
            LOG.error(pe.getCause());
            pe.printStackTrace();
            throw new PersistenceException(pe.getCause());
        }
    }

    public <T> T update(final T entity) throws PersistenceException {
        LOG.debug("update Entity :: START");
        try {
            this.entityManager.merge(entity);
        } catch (final Exception pe) {
            LOG.error(pe.getCause());
            throw new PersistenceException(pe.getCause());
        }
        LOG.debug("update entity :: END ");
        return entity;
    }

    public void remove(final Object entity) throws PersistenceException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("remove [ " + entity + "] :: START");
        }
        try {
            this.entityManager.remove(entity);
            if (LOG.isDebugEnabled()) {
                LOG.debug("remove [ " + entity + "] :: END");
            }
        } catch (final Exception e) {
            LOG.error(e);
            e.printStackTrace();
            throw new PersistenceException(e);
        }
    }

    public void remove(final String queryName, final QueryParameters queryParams) throws PersistenceException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("remove [ " + queryName + "] :: START");
        }
        try {
            final Query query = this.entityManager.createNamedQuery(queryName);
            queryParams.fill(query);
            
            int count = query.executeUpdate();
            System.out.println(count);
            if (LOG.isDebugEnabled()) {
                LOG.debug("remove [ " + queryName + "] :: END");
            }
        } catch (final Exception pe) {
            LOG.error(pe.getCause());
            throw new PersistenceException(pe.getCause());
        }
    }
    
  //Added by Manoj Gupta for pagination
    public <T> List<T> list(final String queryName, final QueryParameters queryParams, int pageSize,int pageNumber, final Class<T> resultClass) throws PersistenceException {
    	if (LOG.isDebugEnabled()) {
            LOG.debug("list [ " + queryName + "] :: START");
        }
        try {
            final TypedQuery<T> query = this.entityManager.createNamedQuery(queryName, resultClass);
            queryParams.fill(query);
            query.setFirstResult((pageNumber-1) * pageSize);
            query.setMaxResults(pageSize);
            query.setFlushMode(FlushModeType.COMMIT);

            final List<T> results = query.getResultList();

            if (LOG.isDebugEnabled()) {
                LOG.debug("list [ " + queryName + "] :: END");
            }
            return results;
        } catch (final javax.persistence.PersistenceException pe) {
            LOG.error(pe.getCause());
            throw new PersistenceException(pe.getCause());
        }
    }
    
    /*public <T> List<T> list(String date) throws PersistenceException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("list [ " + date + "] :: START");
		}
		try {
			final Query query = this.entityManager.createNativeQuery(
					"SELECT DISTINCT cpo.name,cpo.created_time FROM cs_operation cpo where date(created_time) = :createdTime  group by name order by created_time desc ");

			query.setFlushMode(FlushModeType.COMMIT);
			query.setParameter("createdTime", date);
			@SuppressWarnings("unchecked")
			final List<T> results = query.getResultList();
			if (LOG.isDebugEnabled()) {
				LOG.debug("list [ " + date + "] :: END");
			}
			return results;
		} catch (final javax.persistence.PersistenceException pe) {
			LOG.error(pe.getMessage());
			throw new PersistenceException(pe.getMessage());
		}
	}*/
  
   /* public <T> void bulkUpdate(final String queryName, final Object [][] values, final int []idList, final Class<T> resultClass){
    	try {
			CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
			CriteriaUpdate<T> update = builder.createCriteriaUpdate(resultClass);
			System.out.println(3);
			From from = update.from(resultClass);
			for(Object []params : values){
				System.out.println(4);
				update.set(String.valueOf(params[0]), params[1]);
			}
			In<Integer> ids = builder.in(from.get("id"));
			for(int id : idList){
				ids.value(id);
			}
			for(Object []con : condition){
				//update.where(Predicate.BooleanOperator.AND);
				update.where(builder.and(x, y)));
				builder.
			}
			update.where(ids);
			Query query = this.entityManager.createQuery(update);
			query.unwrap(Session.class).setJdbcBatchSize(5);;
			int count = query.executeUpdate();
		
			System.out.println("count "+count);
			System.out.println(5);
			entityManager.createNativeQuery("");
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
*/   
    
    public <T> List<T> list(String date) throws PersistenceException {

  		if (LOG.isDebugEnabled()) {
  			LOG.debug("list [ " + date + "] :: START");
  		}
  		try {
  			final Query query = this.entityManager.createNativeQuery(
  					"SELECT DISTINCT cpo.id,cpo.name,cpo.created_time FROM cp_operation cpo where date(created_time) = :createdTime  group by name order by created_time desc ");

  			query.setFlushMode(FlushModeType.COMMIT);
  			query.setParameter("createdTime", date);
  			@SuppressWarnings("unchecked")
  			final List<T> results = query.getResultList();
  			if (LOG.isDebugEnabled()) {
  				LOG.debug("list [ " + date + "] :: END");
  			}
  			return results;
  		} catch (final javax.persistence.PersistenceException pe) {
  			LOG.error(pe.getMessage());
  			throw new PersistenceException(pe.getMessage());
  		}
  	}
      
      public <T> List<T> list(String date,String type) throws PersistenceException {

  		if (LOG.isDebugEnabled()) {
  			LOG.debug("list [ " + date + "] :: START");
  		}
  		try {
  			final Query query = this.entityManager.createNativeQuery(
  					"SELECT  cpo.name,cpol.msg,cpol.type,cpol.created_time,cpol.id FROM cp_operation cpo "
  					+ " inner join cp_operation_log cpol on cpol.id=cpo.id"
  					+ " where date(cpo.created_time) = :createdTime  and cpo.name=:name  order by cpol.created_time desc, cpo.id,cpol.type ");

  			query.setFlushMode(FlushModeType.COMMIT);
  			query.setParameter("createdTime", date);
  			query.setParameter("name", type);
  			@SuppressWarnings("unchecked")
  			final List<T> results = query.getResultList();
  			if (LOG.isDebugEnabled()) {
  				LOG.debug("list [ " + date + "] :: END");
  			}
  			return results;
  		} catch (final javax.persistence.PersistenceException pe) {
  			LOG.error(pe.getMessage());
  			throw new PersistenceException(pe.getMessage());
  		}
  	}

    public <T> List<T> listCSOperations(String date) throws PersistenceException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("list [ " + date + "] :: START");
		}
		try {
			final Query query = this.entityManager.createNativeQuery(
					"SELECT DISTINCT cso.id,cso.name,cso.created_time FROM cs_operation cso where date(created_time) = :createdTime  group by name order by created_time desc ");

			query.setFlushMode(FlushModeType.COMMIT);
			query.setParameter("createdTime", date);
			@SuppressWarnings("unchecked")
			final List<T> results = query.getResultList();
			if (LOG.isDebugEnabled()) {
				LOG.debug("list [ " + date + "] :: END");
			}
			return results;
		} catch (final javax.persistence.PersistenceException pe) {
			LOG.error(pe.getMessage());
			throw new PersistenceException(pe.getMessage());
		}
	}
    
    public <T> List<T> listCSOperationsWithDate(String date) throws PersistenceException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("list [ " + date + "] :: START");
		}
		try {
			final Query query = this.entityManager.createNativeQuery(
					"SELECT  cso.name,csol.msg,csol.type,csol.created_time,csol.id FROM cs_operation cso "
					+ " inner join cs_operation_log csol on csol.id=cso.id"
					+ " where date(cso.created_time) = :createdTime  order by csol.created_time desc, cso.id,cso.name,csol.type  ");

			query.setFlushMode(FlushModeType.COMMIT);
			query.setParameter("createdTime", date);
			@SuppressWarnings("unchecked")
			final List<T> results = query.getResultList();
			if (LOG.isDebugEnabled()) {
				LOG.debug("list [ " + date + "] :: END");
			}
			return results;
		} catch (final javax.persistence.PersistenceException pe) {
			LOG.error(pe.getMessage());
			throw new PersistenceException(pe.getMessage());
		}
	}
    
    public <T> List<T> listCSOperationsLogs(String date,String type) throws PersistenceException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("list [ " + date + "] :: START");
		}
		try {
			final Query query = this.entityManager.createNativeQuery(
					"SELECT  cso.name,csol.msg,csol.type,csol.created_time,csol.id FROM cs_operation cso "
					+ " inner join cs_operation_log csol on csol.id=cso.id"
					+ " where date(cso.created_time) = :createdTime  and cso.name=:name  order by csol.created_time desc, cso.id,csol.type ");

			query.setFlushMode(FlushModeType.COMMIT);
			query.setParameter("createdTime", date);
			query.setParameter("name", type);
			@SuppressWarnings("unchecked")
			final List<T> results = query.getResultList();
			if (LOG.isDebugEnabled()) {
				LOG.debug("list [ " + date + "] :: END");
			}
			return results;
		} catch (final javax.persistence.PersistenceException pe) {
			LOG.error(pe.getMessage());
			throw new PersistenceException(pe.getMessage());
		}
	}  
    
    public <T> List<T> listConnector(List<String> cpList, int conId) throws PersistenceException {
		try {
			final Query query = this.entityManager.createNativeQuery(
					"SELECT cp.charge_point_id, c.connector_id FROM charge_point cp" 
					+" left join connector c on c.charge_point_id = cp.charge_point_id"
					+" where cp.charge_point_id in :cpList and c.connector_id = :connectorId");

			query.setFlushMode(FlushModeType.COMMIT);
			query.setParameter("cpList", cpList);
			query.setParameter("connectorId", conId);
			@SuppressWarnings("unchecked")
			final List<T> results = query.getResultList();
			return results;
		} catch (final javax.persistence.PersistenceException pe) {
			LOG.error(pe.getMessage());
			throw new PersistenceException(pe.getMessage());
		}
	}
    
    public <T> List<T> listOperations(final String queryName, final QueryParameters queryParams) throws PersistenceException {
		try {
			final Query query = this.entityManager.createNativeQuery(queryName);
			query.setFlushMode(FlushModeType.COMMIT);
			queryParams.fill(query);
			@SuppressWarnings("unchecked")
			final List<T> results = query.getResultList();
			return results;
		} catch (final javax.persistence.PersistenceException pe) {
			LOG.error(pe.getMessage());
			throw new PersistenceException(pe.getMessage());
		}
	}
    
    public <T> List<T> listOperationsPagination(final String queryName, final QueryParameters queryParams, int pageSize, int pageNo) throws PersistenceException {
		try {
			final Query query = this.entityManager.createNativeQuery(queryName);
			query.setFlushMode(FlushModeType.COMMIT);
			queryParams.fill(query);
			 query.setFirstResult((pageNo-1) * pageSize);
	         query.setMaxResults(pageSize);
			@SuppressWarnings("unchecked")
			final List<T> results = query.getResultList();
			return results;
		} catch (final javax.persistence.PersistenceException pe) {
			LOG.error(pe.getMessage());
			throw new PersistenceException(pe.getMessage());
		}
	}

}

