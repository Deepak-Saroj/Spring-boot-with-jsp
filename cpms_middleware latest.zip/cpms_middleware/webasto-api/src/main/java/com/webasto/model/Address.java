package com.webasto.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "address")
public class Address {

	@Id
	@GeneratedValue	( strategy = GenerationType.IDENTITY )
	@Column(name = "id")
	private int id;
	
	@Column(name = "street", length = 1000)
	private String street;
	
	@Column(name = "house_number")
	private String houseNumber;
	
	@Column(name = "zip_code")
	private String zipCode;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "country")
	private String country;
	
	@CreationTimestamp
	@Column(name = "created_time", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date createdTime;
	
	@UpdateTimestamp
	@Column(name = "modified_time", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date modifiedTime;
	
	@Column(name = "location_latitude", columnDefinition = "decimal(11,8) DEFAULT NULL")
	private Double locationLatitude;
	
	@Column(name = "location_longitude", columnDefinition = "decimal(11,8) DEFAULT NULL")
	private Double locationLongitude;
	
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}
	public Date getModifiedTime() {
		return modifiedTime;
	}
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getHouseNumber() {
		return houseNumber;
	}
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Double getLocationLatitude() {
		return locationLatitude;
	}
	public void setLocationLatitude(Double locationLatitude) {
		this.locationLatitude = locationLatitude;
	}
	public Double getLocationLongitude() {
		return locationLongitude;
	}
	public void setLocationLongitude(Double locationLongitude) {
		this.locationLongitude = locationLongitude;
	}
	
	
	
	
}
