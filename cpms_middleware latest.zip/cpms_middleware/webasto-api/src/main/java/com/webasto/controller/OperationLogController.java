package com.webasto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.CSOperation;
import com.webasto.service.OperationLogService;

@RestController
@CrossOrigin
@RequestMapping(value = "/operationfsd/log")
public class OperationLogController {

	@Autowired
	private OperationLogService operationLogService;
	
	@RequestMapping(value = "/search/{date}", method = RequestMethod.GET)
	public ResponseEntity<List<CSOperation> > getOperationLogs(@PathVariable String date) throws ServiceException{
		try {
			System.out.println(date);
			List<CSOperation> obj = operationLogService.getOperations(date);
			return ResponseEntity.ok(obj);
		} catch (ServiceException se) {
			throw new ServiceException("Internal server error");
		}
	}
}
