package com.webasto.commons;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.MailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class OCPPConfiguration{
	
	@Value("${spring.mail.username}")
	private String username;
	@Value("${spring.mail.password}")
	private String password;
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public MailSender mailSender(){
		JavaMailSenderImpl jmsi = new JavaMailSenderImpl();
		jmsi.setHost("smtp.gmail.com");
		jmsi.setUsername(username);
		jmsi.setPassword(password);
		jmsi.setPort(587);
		Properties pro = new Properties();
		pro.put("mail.transport.protocol", "smtp");
		pro.put("mail.smtp.auth", "true");
		pro.put("mail.smtp.starttls.enable", "true");
		jmsi.setJavaMailProperties(pro);		
		return jmsi;
	}	
	
	/*@Bean
	public void webSocket(){
		
	}*/
	

}
