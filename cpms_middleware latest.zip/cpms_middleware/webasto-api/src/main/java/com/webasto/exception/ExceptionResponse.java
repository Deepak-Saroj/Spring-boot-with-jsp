package com.webasto.exception;

import java.time.LocalDateTime;
import java.util.List;


public class ExceptionResponse {

	    
	   // private String message;
	   // private String errors;
	    private String timestamp;
	    private String  status;
	   // private String path;
	  //  private String exception; 
	    private List<String> errorList;
	    
	    //int status, message, long timestamp, error, path, exception
	 
	    
	     ExceptionResponse() {
	    	 timestamp = LocalDateTime.now().toString();
	    }
	    
	     ExceptionResponse(String status) {
	        this();
	        this.status = status;
	    }
	 
	     ExceptionResponse( String timeStamp, String status, List<String > errorList )
	    {
	    	
	    	//this.message= message;
	    	//this.errors = errors;
	    	this.timestamp = timeStamp;
	    	//this.path = path;
	    	//this.exception = exception;
	    	this.status = status;
	    	this.errorList= errorList;
	    	
	    }
	    public String getTimestamp() {
			return timestamp;
		}

		public void setTimestamp(String timestamp) {
			this.timestamp = timestamp;
		}

		/*public String getPath() {
			return path;
		}

		public void setPath(String path) {
			this.path = path;
		}*/

//		public String getException() {
//			return exception;
//		}
//
//		public void setException(String exception) {
//			this.exception = exception;
//		}

		
	 /*
	    public String getMessage() {
	        return message;
	    }
	 
	    public void setMessage(String message) {
	        this.message = message;
	    }*/

		/*public String getErrors() {
			return errors;
		}

		public void setErrors(String errors) {
			this.errors = errors;
		}*/

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public List<String> getErrorList() {
			return errorList;
		}

		public void setErrorList(List<String> errorList) {
			this.errorList = errorList;
		}
	    
}
