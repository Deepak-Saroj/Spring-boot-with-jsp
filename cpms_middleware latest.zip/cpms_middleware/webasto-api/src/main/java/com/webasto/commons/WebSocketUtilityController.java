package com.webasto.commons;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import io.vertx.core.Vertx;
import io.vertx.core.http.HttpClient;
import io.vertx.core.http.WebSocket;
import io.vertx.core.http.WebSocketConnectOptions;

@Configuration
public class WebSocketUtilityController {

	private static WebSocketConnectOptions options;
	private static HttpClient client;
	private static WebSocket ws;

	@Bean
	public WebSocketConnectOptions getConfiguration() {
		options = new WebSocketConnectOptions();
		/*
		 * options.addHeader("Upgrade", "websocket");
		 * options.addHeader("Connection", "Upgrade");
		 * options.addHeader("Sec-WebSocket-Key", "x3JJHMbDL1EzLkh9GBhXDw==");
		 * options.addHeader("Sec-WebSocket-Protocol", "ocpp1.6");
		 * options.addHeader("Sec-WebSocket-Version", "13"); options.setURI(
		 * "/steve/websocket/CentralSystemService/4343847fef9d89d8f7g89c");
		 * options.addSubProtocol("ocpp1.6");
		 */
		options.setHost("3.6.12.18");
		options.setPort(443);

		options.setURI("/cpms");
		return options;

	}

	@Bean
	public HttpClient createClient() {
		client = Vertx.vertx().createHttpClient();
		return client;
	}

	public WebSocket getClientConnection() {
		if (ws == null) {
			ws = createClient().webSocket(getConfiguration()).result();
		}
		return ws;

	}
}