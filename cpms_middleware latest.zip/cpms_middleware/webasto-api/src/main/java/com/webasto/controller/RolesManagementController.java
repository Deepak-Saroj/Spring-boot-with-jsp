package com.webasto.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.Role;
import com.webasto.service.RolesManagementService;
import com.webasto.service.RolesManagementServiceImpl;

@RestController
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RequestMapping(value = "/role")
public class RolesManagementController {

	private static final Logger LOG = LogManager.getLogger(RolesManagementController.class);

	@Autowired
	private RolesManagementService rolesManagementService;
	
	@RequestMapping(value = "/add",method = RequestMethod.POST)
	public ResponseEntity<Role> createRole(@RequestBody Role role) throws UniqueConstraintException, ServiceException{
		try {
			LOG.debug("STARTED : createRole() of UserController class");
			Role newRole = rolesManagementService.addRole(role);
			LOG.debug("ENDED : createRole() of UserController class");
			return ResponseEntity.ok(newRole);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("internal server error");
		}
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.PUT)
	public void updateRole(@RequestBody Role role){
		try {
			rolesManagementService.updateRole(role);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/delete/{roleId}", method = RequestMethod.DELETE)
	public void deleteRole(@RequestBody int roleId){
		try {
			rolesManagementService.deleteRole(roleId);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public void getRoles(){
		try {
			rolesManagementService.roleList();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/{roleId}", method = RequestMethod.GET)
	public void getRole(@PathVariable int roleId){
		try {
			rolesManagementService.getRole(roleId);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
}
