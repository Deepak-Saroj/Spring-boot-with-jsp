package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.CSOperation;
import com.webasto.model.CSOperationLog;

public interface CSOperationControllerService {
	public CSOperation addCSOperation(CSOperation csData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public CSOperationLog addCSOperationLog(CSOperationLog csLogData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public List<CSOperation> getCSOperationList(String date) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public List<CSOperationLog> getCSOperationLogsList(String date,String type) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public List<CSOperationLog> getList(String date)throws ServiceException; 
	public List<CSOperationLog> getOperationLogs(String id)throws ServiceException;
	public List<CSOperation> getAllOperations(String date)throws ServiceException;
	public List<CSOperation> getAllOperationsPagination(String date, int pageSize, int pageNumber)throws ServiceException;
}
