package com.webasto.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "usersd")
@NamedQueries(value = {@NamedQuery(name = "User.findByEmail", query = "SELECT u from User u WHERE u.email = :email"),
					   @NamedQuery(name = "User.list", query = "SELECT u from User u"),
					   @NamedQuery(name = "User.findByToken", query = "SELECT u FROM User u WHERE u.token = :token")
						})
public class User {

	@Id
	@GeneratedValue	( strategy = GenerationType.IDENTITY )
	@Column(name = "id")
	private int userId;
	
	@Column(name = "first_name")
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "full_name")
	private String fullName;
	
	@Column(name = "password")
	//@Pattern(regexp = "^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$")
	private String password;
	
	@Column(name = "login_pin_number")
	private String loginPinNumber;
	
	@Column(name = "gender")
	private String gender;
	
	@Column(name = "phone_no", length = 10)
	private String phone;
	
	@Column(name = "active")
	private Boolean active;
	
	@Column(name = "email_address", unique = true)
	@NotNull
	@Pattern(regexp = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w-]+\\.)+[com]+[\\w]$")
	private String email;
	
	@Column(name = "token")
	private String token;
	
	@Column(name = "token_created_time")
	private Date tokenCreatedTime;
	
	//@JsonDeserialize(using = JsonDateDeserializer.class)
	//@JsonSerialize(using = JsonDateSerializer.class)
	//@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "birth_day")
	private LocalDate dob;
	
	@Transient
	private String dateOfBirth;
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	@Column(name = "note")
	private String note;
	
	@Column(name = "street")
	private String street;
	
	@Column(name = "house_number")
	private String houseNumber;
	
	@Column(name = "zip_code")
	private String zipCode;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "location")
	private String location;
	
	@Transient
	@Column(name = "role_name")
	//@NotNull
	private String roleName;
	
	@Column(name = "dapartment")
	private String department;
	
	/*@OneToOne(mappedBy = "user")
    private UserRole book;*/
	

	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getLoginPinNumber() {
		return loginPinNumber;
	}


	public void setLoginPinNumber(String loginPinNumber) {
		this.loginPinNumber = loginPinNumber;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	

	public Boolean getActive() {
		return active;
	}


	public void setActive(Boolean active) {
		this.active = active;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}


	public Date getTokenCreatedTime() {
		return tokenCreatedTime;
	}


	public void setTokenCreatedTime(Date tokenCreatedTime) {
		this.tokenCreatedTime = tokenCreatedTime;
	}


	public LocalDate getDob() {
		return dob;
	}


	public void setDob(LocalDate dob) {
		this.dob = dob;
	}


	public String getNote() {
		return note;
	}


	public void setNote(String note) {
		this.note = note;
	}


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}


	public String getHouseNumber() {
		return houseNumber;
	}


	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}


	public String getZipCode() {
		return zipCode;
	}


	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getRoleName() {
		return roleName;
	}


	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}

	
	

/*	public UserRole getBook() {
		return book;
	}


	public void setBook(UserRole book) {
		this.book = book;
	}
*/

	
}
