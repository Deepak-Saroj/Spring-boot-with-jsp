package com.webasto.model;

public class TransactionStart {

}
