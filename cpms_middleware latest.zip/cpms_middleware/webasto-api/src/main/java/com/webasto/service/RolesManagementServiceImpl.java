package com.webasto.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.Response;
import com.webasto.model.Role;

@Service
public class RolesManagementServiceImpl implements RolesManagementService{
	
	private static final Logger LOG = LogManager.getLogger(RolesManagementServiceImpl.class);

	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;

	@Override
	@Transactional
	public Role addRole(Role role) throws ServiceException, UniqueConstraintException {
		try {
			LOG.debug("STARTED : addRole() of UserServiceImpl class");
			final Object [][]param = {{"roleName", role.getRoleName()}};
			Role oldRole = securityRelationalRepository.find("Role.findByName", new QueryParameters(param), Role.class);
			if(oldRole != null){
				LOG.error("EXCEPTION : \"role already exist\" raised in addRole() of UserServiceImpl class" );
				throw new UniqueConstraintException("role already exist");
			} else{
				role.setActive(true);
				Role newRole = securityRelationalRepository.create(role);
				LOG.debug("ENDED : addRole() of UserServiceImpl class");
				return newRole;
			}
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of addRole() of UserServiceImpl class");
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
		
	}
	
	@Override
	public Role getRole(int roleId) throws NotFoundException, ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;

	}
	
	@Override
	public List<Role> roleList() throws ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;

	}
	
	@Override
	@Transactional
	public Role updateRole(Role role) throws NotFoundException, ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;

	}
	
	@Override
	@Transactional
	public Response deleteRole(int roleId) throws NotFoundException, ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
}
