package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.CSOperation;
import com.webasto.model.CSOperationLog;

@Service
public class CSOperationControllerServiceImpl implements CSOperationControllerService{
	private static final Logger LOG = LogManager.getLogger(ChargePointServiceImpl.class);

	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;

	/*	@PersistenceContext
	private EntityManager manager;

	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;
	 */

	@Override
	@Transactional
	public CSOperation addCSOperation(CSOperation csOperationData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException {
		try {
			CSOperation cso = securityRelationalRepository.create(csOperationData);
			return cso;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of addChargingPoint() of ChargePointServiceImpl class" );
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe.getCause() : t.getCause());
		}
	}

	@Override
	@Transactional
	public CSOperationLog addCSOperationLog(CSOperationLog cslogData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException {
		try {
			CSOperationLog csol = securityRelationalRepository.create(cslogData);
			return csol;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of addChargingPoint() of ChargePointServiceImpl class" );
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe.getCause() : t.getCause());
		}
	}
	
	@Override
	@Transactional
	public List<CSOperation> getCSOperationList(String date) throws IllegalAccessException, InvocationTargetException, ServiceException {
		try {
			LOG.debug("STARTED : getChargePointOperationList() of CPOperationControllerServiceImpl class: ");
			String query = "SELECT cso.id,cso.name,cso.created_time FROM cs_operation cso where date(created_time) = :createdTime  order by created_time desc";
			//List<ChargePointOperation> chargePointOperationList = securityRelationalRepository.list("ChargePointOperation.list", new QueryParameters(null), ChargePointOperation.class);			
			//List<Object[]> objList1 = securityRelationalRepository.listCSOperations(date);
			final Object [][]param = {{"createdTime", date}};
			List<Object[]> objList1 = securityRelationalRepository.listOperations(query, new QueryParameters(param));
			List<CSOperation> cpolist = new ArrayList<CSOperation>();
			for(Object[] l : objList1){
				CSOperation operation = new CSOperation();
				operation.setId((String)l[0]);
				operation.setName((String)l[1]);
				operation.setCreatedTime((Date)l[2]);
				cpolist.add(operation);	
			}	
			LOG.debug("ENDED : getChargePointOperationList() of CPOperationControllerServiceImpl class");
			return cpolist;
		} catch (Exception pe) {
			LOG.error("EXCEPTION : Catch block executed of getChargePointList() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	@Transactional
	public List<CSOperationLog> getCSOperationLogsList(String date,String type) throws IllegalAccessException, InvocationTargetException, ServiceException {
		try {
			LOG.debug("STARTED : getChargePointOperationList() of CPOperationControllerServiceImpl class: ");
			//List<ChargePointOperation> chargePointOperationList = securityRelationalRepository.list("ChargePointOperation.list", new QueryParameters(null), ChargePointOperation.class);			
			List<Object[]> objList1 = securityRelationalRepository.listCSOperationsLogs(date,type);
			List<CSOperationLog> cpolist = new ArrayList<CSOperationLog>();
			for(Object[] l : objList1){
				CSOperationLog operation = new CSOperationLog();
				operation.setName((String)l[0]);
				operation.setMsg((String)l[1]);
				operation.setType(((Byte)l[2]).intValue());
				operation.setCreatedTime((Date)l[3]);
				operation.setId((String)l[4]);
				cpolist.add(operation);	
			}
			
			
			LOG.debug("ENDED : getChargePointOperationList() of CPOperationControllerServiceImpl class");
			ObjectMapper map = new ObjectMapper();
			return cpolist;
		} catch (Exception pe) {
			LOG.error("EXCEPTION : Catch block executed of getChargePointList() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	public List<CSOperationLog> getList(String date) throws ServiceException {
		try {
			List<Object[]> list = securityRelationalRepository.listCSOperationsWithDate(date);
			List<CSOperationLog> logList = new ArrayList<>();
			for(Object[] obj : list){
				CSOperationLog log = new CSOperationLog();
				log.setName((String)obj[0]);
				log.setMsg((String)obj[1]);
				log.setType(((Byte)obj[2]).intValue());
				log.setCreatedTime((Date)obj[3]);
				log.setId((String)obj[4]);
				logList.add(log);
			}
			return logList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	public List<CSOperationLog> getOperationLogs(String id) throws ServiceException {
		try {
			final Object [][]param = {{"id", id}};
			List<CSOperationLog> logList = new ArrayList<>();
					//securityRelationalRepository.list("CSOperationLog.ListBasedOnId", new QueryParameters(param), CSOperationLog.class);
			String msg = "SELECT * FROM cs_operation_log  WHERE id = :id";
			List<Object[]> list = securityRelationalRepository.listOperations(msg, new QueryParameters(param));
			for(Object[] obj : list){
				CSOperationLog log = new CSOperationLog();
				log.setId((String)obj[0]);
				log.setType(((Byte)obj[1]).intValue());
				log.setMsg((String)obj[2]);
				log.setCreatedTime((Date)obj[3]);
				logList.add(log);
			}
			System.out.println(logList);
			return logList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	public List<CSOperation> getAllOperations(String date) throws ServiceException {
		try {
			String query = "SELECT cso.id,cso.name,csol.type,csol.msg, cso.created_time FROM cs_operation cso left join  cs_operation_log csol on cso.id = csol.id"
					+ " where date(cso.created_time) = :date order by cso.created_time desc, cso.id ";
			final Object[][] param = {{"date", date}};
			List<Object[]> operationLogsList = securityRelationalRepository.listOperations(query, new QueryParameters(param));
			List<CSOperation> logList = new ArrayList<>();
			//String []ids = {};
			List<String> ids = new ArrayList<>();
			CSOperation oper = null;
			List li = null;
			int flage = 0;
			for(Object[] obj : operationLogsList){	
				if(ids.contains(obj[0])){
					CSOperationLog log = new CSOperationLog();
					log.setType(((Byte)obj[2]).intValue());
					log.setMsg((String)obj[3]);
					//log.setCreatedTime((Date)obj[4]);
					li.add(log);
					flage =1;
				} else {
					if(flage == 1){
						oper.setResponse(li);
						logList.add(oper);
						flage = 0;
					}
					li = new ArrayList<>();
					oper = new CSOperation();
					oper.setId((String)obj[0]);
					oper.setName((String)obj[1]);
					oper.setCreatedTime((Date)obj[4]);
					CSOperationLog log = new CSOperationLog();
					log.setType(((Byte)obj[2]).intValue());
					log.setMsg((String)obj[3]);
					//log.setCreatedTime((Date)obj[4]);
					li.add(log);
					ids.add(oper.getId());
					flage =1;
				}
				
				
			}
			System.out.println(logList);
			return logList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}

	}
	
@Override
public List<CSOperation> getAllOperationsPagination(String date, int pageSize, int pageNumber) throws ServiceException {
	try {
		String query = "SELECT cso.id,cso.name,csol.type,csol.msg, cso.created_time FROM `cpms`.`cs_operation` cso left join  `cpms`.`cs_operation_log` csol on cso.id = csol.id"
				+ " where date(cso.created_time) = :date order by cso.created_time desc, cso.id ";
		final Object[][] param = {{"date", date}};
		List<Object[]> operationLogsList = securityRelationalRepository.listOperationsPagination(query, new QueryParameters(param), pageSize, pageNumber);
		List<CSOperation> logList = new ArrayList<>();
		//String []ids = {};
		List<String> ids = new ArrayList<>();
		CSOperation oper = null;
		List li = null;
		int flage = 0;
		for(Object[] obj : operationLogsList){	
			if(ids.contains(obj[0])){
				CSOperationLog log = new CSOperationLog();
				log.setType(((Byte)obj[2]).intValue());
				log.setMsg((String)obj[3]);
				//log.setCreatedTime((Date)obj[4]);
				li.add(log);
				flage =1;
			} else {
				if(flage == 1){
					oper.setResponse(li);
					logList.add(oper);
					flage = 0;
				}
				li = new ArrayList<>();
				oper = new CSOperation();
				oper.setId((String)obj[0]);
				oper.setName((String)obj[1]);
				oper.setCreatedTime((Date)obj[4]);
				CSOperationLog log = new CSOperationLog();
				log.setType(((Byte)obj[2]).intValue());
				log.setMsg((String)obj[3]);
				//log.setCreatedTime((Date)obj[4]);
				li.add(log);
				ids.add(oper.getId());
				flage =1;
			}
			
			
		}
		System.out.println(logList);
		return logList;
	} catch (Exception e) {
		// TODO: handle exception
	}
	return null;
}
}
