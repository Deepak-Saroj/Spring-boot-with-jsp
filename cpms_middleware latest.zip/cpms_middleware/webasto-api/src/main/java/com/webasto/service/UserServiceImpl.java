package com.webasto.service;


import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.BulkActiveDeactive;
import com.webasto.model.ChargePoint;
import com.webasto.model.ChargePointData;
import com.webasto.model.Response;
import com.webasto.model.Role;
import com.webasto.model.User;
import com.webasto.model.UserData;
import com.webasto.model.UserLogin;
import com.webasto.model.UserRole;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger LOG = LogManager.getLogger(UserServiceImpl.class);
	
	@PersistenceContext
	private EntityManager entityMan;
	
	@Value("${spring.mail.username}")
	private String username;
	@Value("${spring.mail.password}")
	private String password;
	@Value("${spring.reactUrl}")
	private String reactUrl;
	
	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Override
	@Transactional
	public Response createUser(User user) throws UniqueConstraintException, ServiceException, AddressException, MessagingException, ParseException {
		
			try {
				LOG.debug("STARTED : createUser() of UserServiceImpl class");
				final Object param[][] = {{"email", user.getEmail()}};
				User user1 = securityRelationalRepository.find("User.findByEmail", new QueryParameters(param), User.class);		
				if(user1 != null){
					LOG.error("EXCEPTION : \"User already exist \" raised in createUser() of UserServiceImpl class" );
					throw new UniqueConstraintException("user already exist");
				} else {
					user.setFullName(user.getFirstName() + " " + user.getLastName());
					//String location = "house no " + user.getHouseNumber() + ", " + user.getStreet() + ", " + user.getCity() + ", " + user.getCountry() + ", " + user.getZipCode();
					//user.setLocation(location);
					//Calendar cal = Calendar.getInstance();
					//user.setBirthDay(cal.getTime());
					//System.out.println(user.getBirthDay());
					Random random = new Random();
					String pwd = "Ocpp@"+String.format("%04d", random.nextInt(10000));
					System.out.println(pwd);
					String password = bCryptPasswordEncoder.encode(pwd);
					System.out.println(password);
					user.setPassword(password);
					System.out.println("date "+user.getDateOfBirth());
					SimpleDateFormat dateFoemat = new SimpleDateFormat("dd-MM-yyyy");
					//System.out.println(dateFoemat.parse(user.getDateOfBirth()));
					
					System.out.println(user.toString());
					//user1 = securityRelationalRepository.create(user);
					user.setActive(true);
					Role role = new Role();
					role.setRoleName(user.getRoleName());
					role.setActive(true);
					Role role1 = securityRelationalRepository.create(role);
					
					UserRole userRole = new UserRole();
					userRole.setRoleId(role1.getId());
					//userRole.setUserId(user1.getUserId());
					userRole.setUser(user);
					UserRole userRole1 = securityRelationalRepository.create(userRole);
					sendMail(user, pwd);
					System.out.println(2);
					LOG.debug("ENDED : createUser() of UserServiceImpl class");
					Response res = new Response();
					res.setMessage("success");
					return res;
				}
			} catch (PersistenceException pe) {
				LOG.error("EXCEPTION : Catch block executed of createUser() of UserServiceImpl class");
				throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
			}
				
	}
	
	@Override
	public List<UserLogin> getUserList() throws ServiceException {
		try {
			LOG.debug("STARTED : getUserList() of UserServiceImpl class");
			//List<User> userList = securityRelationalRepository.list("User.list", new QueryParameters(null), User.class);
			List<UserLogin> usersList = securityRelationalRepository.list("UserLogin.list", new QueryParameters(null), UserLogin.class);
			List<UserLogin> users = new ArrayList<>();
			for(UserLogin login : usersList){
				login.setPassword("");
				users.add(login);
			}
			LOG.debug("ENDED : getUserList() of UserServiceImpl class");
			return users;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of getUserList() of UserServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	public UserData editUser(User user) throws UniqueConstraintException, ServiceException, PersistenceException {
		try {
			LOG.debug("STARTED : editUser() of UserServiceImpl class");
			User user1 = securityRelationalRepository.find(user.getUserId(), User.class);
			if(!user.getEmail().equalsIgnoreCase(user1.getEmail())){	
				final Object param [][] = {{"email", user.getEmail()}};
				User user2 = securityRelationalRepository.find("User.findByEmail", new QueryParameters(param), User.class);
				if(user2 != null){
					LOG.error("EXCEPTION : \"Please enter unique email id \" raised in editUser() of UserServiceImpl class" );
					throw new UniqueConstraintException("please enter unique email id");
				} else{		
					user1.setFirstName(user.getFirstName());
					user1.setLastName(user.getLastName());
					//user1.setBirthDay(user.getBirthDay());
					user1.setEmail(user.getEmail());
					user1.setGender(user.getGender());
					user1.setPhone(user.getPhone());
					user1.setRoleName(user.getRoleName());
					user1.setDepartment(user.getDepartment());
					user1.setNote(user.getNote());
					user1.setStreet(user.getStreet());
					user1.setHouseNumber(user.getHouseNumber());
					user1.setZipCode(user.getZipCode());
					user1.setCity(user.getCity());
					user1.setCountry(user.getCountry());
					User user3 = securityRelationalRepository.update(user1);
					UserData data = new UserData();
					BeanUtils.copyProperties(data, user3);
				}
			} else{
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	
	@Override
	public UserData getUser(int userId) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException {
		try {
			LOG.debug("STARTED : getUser() of UserServiceImpl class");
			//final Object param[][] = {{"email", emailId}};
			User user = securityRelationalRepository.find(userId, User.class);
			 //= securityRelationalRepository.find("User.findByEmail", new QueryParameters(param),User.class);
			if(user == null){
				LOG.error("EXCEPTION : \"User does not exist \" raised in getUser() of UserServiceImpl class" );
				throw new NotFoundException("user does not exist");
			}
			UserData data = new UserData();
			BeanUtils.copyProperties(data, user);
			LOG.debug("ENDED : getUser() of UserServiceImpl class");
			return data;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of getUser() of UserServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}

	private void sendMail(User user, String pwd) throws AddressException, MessagingException{
		Properties props = new Properties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});
		MimeMessage msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress(username, false));
		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user.getEmail()));
		msg.setSubject("OCPP Registration Success");
	//	msg.setDescription(emailmessage.getFarmerId());
		//hard coded html due to not finding resource folder for temporary purpose
		msg.setContent("<!DOCTYPE html>\r" + 
				"<html>\r" + 
				"<head>\r" + 
				"<style>\r" + 
				".button {\r" + 
				"  background-color: #23a465;\r\n" + 
				"  border: none;\r" + 
				"  color: white;\r" + 
				"  padding: 15px 32px;\r" + 
				"  text-align: center;\r" + 
				"  text-decoration: none;\r" + 
				"  display: inline-block;\r" + 
				"  font-size: 16px;\r\n" + 
				"  margin: 10px 2px;\r\n" + 
				"  cursor: pointer;\r\n" + 
				"}\r\n" + 
				"</style>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + "<h4>Email: "+user.getEmail()+"</h4>"+"<h4>Password: "+pwd+"</h4>"+
				"Click 'Here' to login page and 'Change Password' immediately ( 'Here' link should be redirected to login page)\r\n" +
				"\r\n" + 
				"\r\n" + 
				"<a href="+reactUrl+">Login</a>.\r\n" +
				
				"<br><b> Note :</b> Please do not reply to this email, Emails sent to this address will not be answered.\r\n"+
				"</body>\r\n" + 
				"</html>","text/html");
		msg.setSentDate(new Date());
		// sends the e-mail
		Transport.send(msg);	
	}
	
	@Override
	@Transactional
	public Response deleteUser(int userId) throws NotFoundException, ServiceException {
		try {
			LOG.debug("STARTED : deleteUser() of UserServiceImpl class");
			//final Object [][]param = {{"email", emailId}};
			User user = securityRelationalRepository.find(userId, User.class);
			//User user = securityRelationalRepository.find("User.findByEmail", new QueryParameters(param), User.class);
			if (user == null) {
				LOG.error("EXCEPTION : \"User not found \" raised in deleteUser() of UserServiceImpl class" );
				throw new NotFoundException("user not found ");
			} else {
				final Object [][]params = {{"userId", user}};
				UserRole role = securityRelationalRepository.find("UserRole.findByUserId", new QueryParameters(params), UserRole.class);
				securityRelationalRepository.remove(role);
				Response res = new Response();
				res.setMessage("success");
				LOG.debug("ENDED : deleteUser() of UserServiceImpl class");
				return res;
			}
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of deleteUser() of UserServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	public List<User> getUserList(int pageNumber, int pageSize) throws ServiceException {
		try {
			LOG.debug("STARTED : getUserList() of UserServiceImpl class");
			List<User> listUser = securityRelationalRepository.list("User.list", new QueryParameters(null), pageSize, pageNumber, User.class);
			System.out.println("size"+listUser.size());		
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of getUserList() of UserServiceImpl class");
			System.out.println(pe);
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
		return null;
	}
	
	@Override
	@Transactional
	public List<User> addBulkUser(List<User> users, int batchSize) throws ServiceException, UniqueConstraintException {
		try {
			LOG.debug("STARTED : createUser() of UserServiceImpl class");

			int i = 0;
			List<User> use = new ArrayList<User>(users.size());
			for(User user : users){
				System.out.println(1);
				if(i % batchSize == 0){
					
					System.out.println(2);
				}
				this.entityMan.persist(user);
				use.add(user);
				i++;
			}
			//return securityRelationalRepository.bulkInsert(users, batchSize);
			LOG.debug("add bulk user method is completed");
			return use;
		} catch (Exception pe) {
			LOG.error("EXCEPTION : Catch block executed of addBulkUser() of UserServiceImpl class");
			pe.printStackTrace();
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	@Transactional
	public List<UserLogin> activateOrDeactivateUser(BulkActiveDeactive activeDeactive) throws ServiceException {
		try {
			List<UserLogin> updatedUserList = new ArrayList<>();
			List<Integer> idList = activeDeactive.getId();
			for(Integer id : idList){
				UserLogin userLogin = securityRelationalRepository.find(id, UserLogin.class);
				if(userLogin != null){
					if(userLogin.getActive() == activeDeactive.getActive()){
					} else {
						userLogin.setActive(activeDeactive.getActive());
						UserLogin updatedUser = securityRelationalRepository.update(userLogin);
						updatedUser.setPassword("");
						updatedUserList.add(updatedUser);
					}		
				} 
			}
			return updatedUserList;
		} catch (PersistenceException pe) {
			pe.printStackTrace();
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
}
