package com.webasto.model;

import java.util.List;

public class OcppTagResponse {
	
	private String message;
	private Object data;
	private List<Object> parentIdTags;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public List<Object> getParentIdTags() {
		return parentIdTags;
	}
	public void setParentIdTag(List<Object> parentIdTags) {
		this.parentIdTags = parentIdTags;
	}
	
	

}
