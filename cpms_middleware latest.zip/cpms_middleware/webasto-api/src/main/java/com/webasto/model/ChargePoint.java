package com.webasto.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.TimeZone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


@Entity
@Table(name = "charge_point")
@NamedQueries(value = {@NamedQuery(name = "ChargePoint.findByChargePointId", query ="SELECT c FROM ChargePoint c WHERE c.chargePointId = :chargePointId"),
					   @NamedQuery(name = "ChargePoint.list", query = "SELECT c FROM ChargePoint c"),
					   @NamedQuery(name = "ChargePoint.DeleteList", query = "DELETE FROM ChargePoint WHERE id IN :idList"),
					   @NamedQuery(name = "ChargePoint.count", query = "SELECT count(*) FROM ChargePoint"),
					   @NamedQuery(name = "ChargePoint.Active", query = "SELECT count(*) FROM ChargePoint c WHERE c.active = 1")})
public class ChargePoint implements Serializable{

	@Id
	@GeneratedValue	( strategy = GenerationType.IDENTITY )
	@Column(name = "id")
	private int id;
	
	@Column(name = "charge_point_id", unique = true, nullable = false)
	@NotNull(message = "Chargepoint id is required")
	@Pattern(regexp = "^.{1,}$", message= "Chargepoint id is required")
	private String chargePointId;
	
	@Column(name = "charge_point_vendor")
	private String chargePointVendor;

	@Column(name = "charge_point_model")
	private String chargePointModel;

	@Column(name = "charge_point_serial_number")
	private String chargePointSerialNumber;

	@Column(name = "charge_box_serial_number")
	private String chargeBoxSerialNumber;

	@Column(name = "fw_version")
	private String fwVersion;
	
	@Column(name = "iccid")
	private String iccid;

	@Column(name = "imsi")
	private String imsi;

	@Column(name = "meter_type")
	private String meterType;

	@Column(name = "meter_serial_number")
	private String meterSerialNumber;

	@Column(name = "description", columnDefinition = "mediumtext")
	private String description;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id")
	private Address address;
	
	@Column(name = "active")
	private Short active;
	
	@CreationTimestamp
	@Column(name = "created_time", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date createdTime;
	
	@UpdateTimestamp
	@Column(name = "modified_time", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date modifiedTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getChargePointId() {
		return chargePointId;
	}

	public void setChargePointId(String chargePointId) {
		this.chargePointId = chargePointId;
	}

	public String getChargePointVendor() {
		return chargePointVendor;
	}

	public void setChargePointVendor(String chargePointVendor) {
		this.chargePointVendor = chargePointVendor;
	}

	public String getChargePointModel() {
		return chargePointModel;
	}

	public void setChargePointModel(String chargePointModel) {
		this.chargePointModel = chargePointModel;
	}

	public String getChargePointSerialNumber() {
		return chargePointSerialNumber;
	}

	public void setChargePointSerialNumber(String chargePointSerialNumber) {
		this.chargePointSerialNumber = chargePointSerialNumber;
	}

	public String getChargeBoxSerialNumber() {
		return chargeBoxSerialNumber;
	}

	public void setChargeBoxSerialNumber(String chargeBoxSerialNumber) {
		this.chargeBoxSerialNumber = chargeBoxSerialNumber;
	}

	public String getFwVersion() {
		return fwVersion;
	}

	public void setFwVersion(String fwVersion) {
		this.fwVersion = fwVersion;
	}

	public String getIccid() {
		return iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public String getMeterType() {
		return meterType;
	}

	public void setMeterType(String meterType) {
		this.meterType = meterType;
	}

	public String getMeterSerialNumber() {
		return meterSerialNumber;
	}

	public void setMeterSerialNumber(String meterSerialNumber) {
		this.meterSerialNumber = meterSerialNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Short getActive() {
		return active;
	}

	public void setActive(Short active) {
		this.active = active;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) throws ParseException {
		/*if(createdTime != null){
		final SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm");
 		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
 		createdTime=sdf.parse(sdf.format(createdTime));
 		}*/
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	
	

}
