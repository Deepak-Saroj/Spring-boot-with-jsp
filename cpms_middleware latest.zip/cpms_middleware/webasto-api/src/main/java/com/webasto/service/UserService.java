package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.BulkActiveDeactive;
import com.webasto.model.Response;
import com.webasto.model.User;
import com.webasto.model.UserData;
import com.webasto.model.UserLogin;

public interface UserService {

	public Response createUser(User user) throws UniqueConstraintException, ServiceException, PersistenceException, AddressException, MessagingException, ParseException;
	public UserData editUser(User user)throws UniqueConstraintException, ServiceException, PersistenceException;
	public UserData getUser(int userId)throws NotFoundException,ServiceException, IllegalAccessException, InvocationTargetException;
	public Response deleteUser(int userId) throws NotFoundException, ServiceException;
	public List<User> getUserList(int pageNumber, int pageSize)throws ServiceException;
	public List<User> addBulkUser(List<User> users, int batchSize)throws ServiceException, UniqueConstraintException;
	
	//user login table
	public List<UserLogin> getUserList()throws ServiceException;
	public List<UserLogin> activateOrDeactivateUser(BulkActiveDeactive activeDeactive)throws ServiceException;
	

	
	

	
	
	
}
