package com.webasto.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private SecurityRelationalRepository securityRelationRepository;
	
	@Override
	public List<Transaction> getTransactionList() throws ServiceException {
		try {
			List<Transaction> transactionList = securityRelationRepository.list("Transaction.list", new QueryParameters(null), Transaction.class);
			return transactionList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
		
	}
}
