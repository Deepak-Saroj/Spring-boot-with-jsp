package com.webasto.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "connector" , uniqueConstraints = @UniqueConstraint(columnNames = {"charge_point_id", "connector_id"}))
@NamedQueries(value = {@NamedQuery(name = "Connector.list", query = "SELECT c from Connector c")})
public class Connector {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@ManyToOne
	@JoinColumn(name = "charge_point_id", referencedColumnName = "charge_point_id")
	private ChargePoint chargePointId;
	
	@Column(name = "connector_id")
	private Integer connectorId;
	
	@Column(name = "created_time")
	private Date createdTime;
	
	@Column(name = "modified_time")
	private Date modifiedTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ChargePoint getChargePointId() {
		return chargePointId;
	}

	public void setChargePointId(ChargePoint chargePointId) {
		this.chargePointId = chargePointId;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	
	
}
