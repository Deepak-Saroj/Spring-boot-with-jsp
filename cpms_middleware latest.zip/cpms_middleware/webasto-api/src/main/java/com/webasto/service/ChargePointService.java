package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;

import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.BulkActiveDeactive;
import com.webasto.model.ChargePoint;
import com.webasto.model.ChargePointData;
import com.webasto.model.ChargingProfile;
import com.webasto.model.Connector;
import com.webasto.model.Response;
import com.webasto.model.UnknownChargePoint;

public interface ChargePointService {

	public ChargePointData addChargingPoint(ChargePoint chargePointData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public List<ChargePointData> getChargePointList() throws IllegalAccessException, InvocationTargetException, ServiceException;
	public ChargePointData getChargePoint(int id)throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException, ParseException;
	public ChargePointData updateChargePoint(ChargePoint chargePoint) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException, InvalidDataException;
	public Response deleteChargePoint(int id)throws NotFoundException, ServiceException;
	public Response deleteChargePoints(List<Integer> idList) throws NotFoundException, ServiceException ;
	public List<ChargePointData> activateOrDeactivateChargePoint(ChargePointData chargePoint)throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException;
	public ChargingProfile addChargingProfile(ChargingProfile chargingProfile)throws ServiceException;
	public ChargingProfile getChargingProfile(int chargingProfileId)throws NotFoundException, ServiceException;
	public List<ChargingProfile> getChargingProfileList()throws ServiceException;
	public ChargingProfile updateChargingProfile(ChargingProfile chargingProfile) throws NotFoundException, ServiceException;
	public Response deleteChargingProfile(int chargingProfileId)throws NotFoundException, ServiceException;
	public void chargePointStatus()throws ServiceException;
	public List<UnknownChargePoint> getUnknownChargePointList()throws ServiceException;
	public List<ChargePointData> activateOrDeactivateBulkChargePoint(BulkActiveDeactive bulkActiveDeactiveList) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException;
	public List<String> getConnector(List<String> cpList, int conId)throws ServiceException;
	
	
}
