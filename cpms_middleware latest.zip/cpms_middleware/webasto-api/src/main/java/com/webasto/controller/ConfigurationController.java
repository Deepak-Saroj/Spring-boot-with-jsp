package com.webasto.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.Configuration;
import com.webasto.model.Response;
import com.webasto.model.ResponseList;
import com.webasto.service.ConfigurationService;

@CrossOrigin
@RestController
@RequestMapping("/configuration")
public class ConfigurationController {

	@Autowired
	private ConfigurationService configurationService;
	
	@RequestMapping(value = "/edit", method = RequestMethod.PUT)
	public ResponseEntity<Response> updateConfiguration(@RequestBody Configuration configuration) throws ServiceException, PersistenceException{
		try {
			Configuration updatedConfiguration = configurationService.updateConfiguration(configuration);
			Response response = new Response();
			response.setData(updatedConfiguration);
			response.setMessage("Heartbeat interval is updated successfully");	
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			throw new ServiceException("Internal server error");
		}
	}
	@RequestMapping(value = "/edits", method = RequestMethod.PUT)
	public ResponseEntity<Response> updateConfigurations(@RequestBody Map<String, Object> configuration) throws ServiceException, PersistenceException{
		try {
			Configuration updatedConfiguration = configurationService.updateConfigurations(configuration);
			Response response = new Response();
			response.setData(updatedConfiguration);
			response.setMessage("Heartbeat interval is updated successfully");	
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ResponseEntity<Response> getConfiguration() throws ServiceException{
		try {
			Configuration configuration = configurationService.getConfiguration();
			Response response = new Response();
			response.setData(configuration);
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/searchs", method = RequestMethod.GET)
	public ResponseEntity<ResponseList> getConfigurations() throws ServiceException{
		try {
			List configurationList = configurationService.getConfigurations();
			ResponseList response = new ResponseList();
			response.setData(configurationList);
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			throw new ServiceException("Internal server error");
		}
	}
}
