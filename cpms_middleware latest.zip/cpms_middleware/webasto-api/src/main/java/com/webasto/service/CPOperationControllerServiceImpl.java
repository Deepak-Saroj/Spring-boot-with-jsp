package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.ChargePointOperation;
import com.webasto.model.ChargePointOperationLog;

@Service
public class CPOperationControllerServiceImpl implements CPOperationControllerService {
	private static final Logger LOG = LogManager.getLogger(ChargePointServiceImpl.class);

	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;

	/*	@PersistenceContext
	private EntityManager manager;

	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;
	 */
	
	

	@Override
	@Transactional
	public ChargePointOperation addCPOperation(ChargePointOperation chargePointOperationData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException {
		try {
			ChargePointOperation newChargePoint = securityRelationalRepository.create(chargePointOperationData);
			return newChargePoint;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of addChargingPoint() of ChargePointServiceImpl class" );
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe.getCause() : t.getCause());
		}
	}

	@Override
	@Transactional
	public ChargePointOperationLog addCPOperationLog(ChargePointOperationLog chargePointOperationlogData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException {
		try {
			ChargePointOperationLog newChargePointOperationLog = securityRelationalRepository.create(chargePointOperationlogData);
			return newChargePointOperationLog;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of addChargingPoint() of ChargePointServiceImpl class" );
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe.getCause() : t.getCause());
		}
	}
	
	@Override
	@Transactional
	public List<ChargePointOperation> getChargePointOperationList(String date) throws IllegalAccessException, InvocationTargetException, ServiceException {
		try {
			LOG.debug("STARTED : getChargePointOperationList() of CPOperationControllerServiceImpl class: ");
			//List<ChargePointOperation> chargePointOperationList = securityRelationalRepository.list("ChargePointOperation.list", new QueryParameters(null), ChargePointOperation.class);			
			List<Object[]> objList1 = securityRelationalRepository.list(date);
			List<ChargePointOperation> cpolist = new ArrayList<ChargePointOperation>();
			for(Object[] l : objList1){
				ChargePointOperation operation = new ChargePointOperation();
				operation.setId((String)l[0]);
				operation.setName((String)l[1]);
				operation.setCreatedTime((Date)l[2]);
				cpolist.add(operation);	
			}
			
			
			LOG.debug("ENDED : getChargePointOperationList() of CPOperationControllerServiceImpl class");
			ObjectMapper map = new ObjectMapper();
			return cpolist;
		} catch (Exception pe) {
			LOG.error("EXCEPTION : Catch block executed of getChargePointList() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	@Transactional
	public List<ChargePointOperationLog> getChargePointOperationLogsList(String date,String type) throws IllegalAccessException, InvocationTargetException, ServiceException {
		try {
			LOG.debug("STARTED : getChargePointOperationList() of CPOperationControllerServiceImpl class: ");
			//List<ChargePointOperation> chargePointOperationList = securityRelationalRepository.list("ChargePointOperation.list", new QueryParameters(null), ChargePointOperation.class);			
			List<Object[]> objList1 = securityRelationalRepository.list(date,type);
			List<ChargePointOperationLog> cpolist = new ArrayList<ChargePointOperationLog>();
			for(Object[] l : objList1){
				ChargePointOperationLog operation = new ChargePointOperationLog();
				operation.setName((String)l[0]);
				operation.setMsg((String)l[1]);
				operation.setType(((Byte)l[2]).intValue());
				operation.setCreatedTime((Date)l[3]);
				operation.setId((String)l[4]);
				cpolist.add(operation);	
			}
			
			
			LOG.debug("ENDED : getChargePointOperationList() of CPOperationControllerServiceImpl class");
			ObjectMapper map = new ObjectMapper();
			return cpolist;
		} catch (Exception pe) {
			LOG.error("EXCEPTION : Catch block executed of getChargePointList() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	

}
