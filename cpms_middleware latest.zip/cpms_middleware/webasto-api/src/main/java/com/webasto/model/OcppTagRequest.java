package com.webasto.model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;

public class OcppTagRequest {

	
	private int id;
	
	@NotNull(message = "ID Tag is required")
	@Pattern(regexp = "^.{1,20}$", message= "ID Tag is required and length should be upto 20 character")
	private String idTag;
	
	
	private OcppTag parentIdTag;
	
	@JsonFormat(pattern="MM-dd-yyyy HH:mm")
	//@Column(name = "expiry_date", columnDefinition = "timestamp(6) NULL DEFAULT NULL")
	private LocalDateTime expiryDate;
			
	public LocalDateTime getExpiryDate() {
		return expiryDate;
	}
	
	public void setExpiryDate(LocalDateTime expiryDate)  {
		String id;
		if(expiryDate != null){
		final SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm");
 		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
 		id=sdf.format(Date.from(expiryDate.atZone( ZoneId.systemDefault()).toInstant()));
 		//id=sdf.format(Date.from(expiryDate.atZone( ZoneId.of("UTC")).toInstant()));
 		DateTimeFormatter form = DateTimeFormatter.ofPattern("MM-dd-yyyy HH:mm");
 		expiryDate = LocalDateTime.parse(id,form);
 		}
		this.expiryDate = expiryDate;
	}
	
	private String expDate;
	
	@NotNull(message = "Blocked field value is required")
	private Short blocked;
	
	//@NotNull(message = "In Transaction field value is required")
	private Short inTransaction;
		
	private String note;
	
	public String getIdTag() {
		return idTag;
	}
	public void setIdTag(String idTag) {
		this.idTag = idTag;
	}
	public OcppTag getParentIdTag() {
		return parentIdTag;
	}
	public void setParentIdTag(OcppTag parentIdTag) {
		this.parentIdTag = parentIdTag;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Short getBlocked() {
		return blocked;
	}
	public void setBlocked(Short blocked) {
		this.blocked = blocked;
	}
	public Short getInTransaction() {
		return inTransaction;
	}
	public void setInTransaction(Short inTransaction) {
		this.inTransaction = inTransaction;
	}
	

	
	
}
