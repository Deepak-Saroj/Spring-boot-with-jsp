package com.webasto.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


/**
 * Hello world!
 *
 */
@SpringBootApplication
@ComponentScan("com.webasto")
@EntityScan("com.webasto")
@EnableWebSecurity
public class WebastoApplication extends WebSecurityConfigurerAdapter 
{
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.csrf().disable();
	}
    public static void main( String[] args )
    {
        SpringApplication.run(WebastoApplication.class, args);
    }
}
