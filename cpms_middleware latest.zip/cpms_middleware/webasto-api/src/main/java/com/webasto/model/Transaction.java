package com.webasto.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import org.hibernate.annotations.UpdateTimestamp;

//@Entity
//@Table(name = "transaction")
@NamedQueries(value = {@NamedQuery(name = "Transaction.list", query = "SELECT t FROM Transaction t")})
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	//@ManyToOne
	//@JoinColumn(name = "connector_id")
	//private Connector connecterId;
	
	@ManyToOne
	@JoinColumn(name = "id_tag", referencedColumnName = "id_tag")
	private OcppTag idTag;
	
	@Column(name = "start_time")
	private Date startTime;
	
	@Column(name = "start_value")
	private String startValue;
	
	@Column(name = "stop_time")
	private Date stopTime;
	
	@Column(name = "stop_value")
	private String stopValue;
	
	@Column(name = "stop_reason")
	private String stopReason;
	
	@CreationTimestamp
	@Column(name = "created_time")
	private Date createdTime;

	@UpdateTimestamp
	@Column(name = "modified_time")
	private Date modifiedTime;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/*public Connector getConnecterId() {
		return connecterId;
	}

	public void setConnecterId(Connector connecterId) {
		this.connecterId = connecterId;
	}*/

	public OcppTag getIdTag() {
		return idTag;
	}

	public void setIdTag(OcppTag idTag) {
		this.idTag = idTag;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public String getStartValue() {
		return startValue;
	}

	public void setStartValue(String startValue) {
		this.startValue = startValue;
	}

	public Date getStopTime() {
		return stopTime;
	}

	public void setStopTime(Date stopTime) {
		this.stopTime = stopTime;
	}

	public String getStopValue() {
		return stopValue;
	}

	public void setStopValue(String stopValue) {
		this.stopValue = stopValue;
	}

	public String getStopReason() {
		return stopReason;
	}

	public void setStopReason(String stopReason) {
		this.stopReason = stopReason;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	
	
	
}
