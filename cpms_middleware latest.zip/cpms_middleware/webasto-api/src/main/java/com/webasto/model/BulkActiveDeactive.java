package com.webasto.model;

import java.util.List;

public class BulkActiveDeactive {
	private List<Integer> id;
	private Short active;
	public List<Integer> getId() {
		return id;
	}
	public void setId(List<Integer> id) {
		this.id = id;
	}
	public Short getActive() {
		return active;
	}
	public void setActive(Short active) {
		this.active = active;
	}
	
	

}
