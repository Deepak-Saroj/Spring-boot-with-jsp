package com.webasto.service;


import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.OcppTag;
import com.webasto.model.OcppTagRequest;
import com.webasto.model.Response;

@Service
public class OCPPTagServiceImpl implements OCPPTagService{

	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;
	
	@PersistenceContext
	private EntityManager manager;
	
	
	@Override
	@Transactional
	public OcppTagRequest createOCPPTag(OcppTagRequest ocppTag) throws UniqueConstraintException, ServiceException, InvalidDataException, IllegalAccessException, InvocationTargetException, ParseException {
		try {
			final Object param[][] = {{"idTag", ocppTag.getIdTag()}};
			OcppTag oldOcppTag = securityRelationalRepository.find("OcppTag.FindByIdTag", new QueryParameters(param), OcppTag.class);
			if(oldOcppTag != null){
				System.out.println(1);
				throw new UniqueConstraintException("Id tag is already exists");
			} else {
				OcppTag parentIdTag = null;
				if(ocppTag.getParentIdTag().getIdTag() != null && ocppTag.getParentIdTag().getIdTag() != ""){
					if(ocppTag.getIdTag().equals(ocppTag.getParentIdTag().getIdTag())){
						throw new InvalidDataException("Id tag and parent id tag should not be equal");
					}
					final Object params[][] = {{"idTag", ocppTag.getParentIdTag().getIdTag()}};
					parentIdTag = securityRelationalRepository.find("OcppTag.FindByIdTag",new QueryParameters(params), OcppTag.class);
					if(parentIdTag == null){
						throw new InvalidDataException("Please enter valid parent id tag");
					}
					else if(parentIdTag != null && parentIdTag.getParentIdTag() != null){
						throw new InvalidDataException("A child id tag can not become the parent of another id tag");
					}
				}
				/*if(ocppTag.getExpiryDate() != null){
					long expiryTime = ocppTag.getExpiryDate().getTime();
					long currentTime = Calendar.getInstance().getTime().getTime();
					if(currentTime > expiryTime){
						throw new InvalidDataException("Expiry date should not less then current date");
					}
				}*/
				//System.out.println(ocppTag.getExpiryDate());
				OcppTag tag = new OcppTag();
				BeanUtils.copyProperties(tag, ocppTag);
				tag.setParentIdTag(parentIdTag);
				//tag.setExpiryDate(date);
				//tag.setBlocked((short)1);
				//tag.setInTransaction(ocppTag.getInTransaction());	
				OcppTag newOcppTag = securityRelationalRepository.create(tag);
				BeanUtils.copyProperties(ocppTag, newOcppTag);
				return ocppTag;
			}
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	
	@Override
	public OcppTagRequest getOCPPTag(int ocppTagId) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException {
		try {
			OcppTagRequest tag = new OcppTagRequest();
			OcppTag ocppTag = securityRelationalRepository.find(ocppTagId, OcppTag.class);
			if(ocppTag == null){
				throw new NotFoundException("Ocpp tag does not exists");
			} else{
				BeanUtils.copyProperties(tag, ocppTag);
				return tag;
			}
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	
	
	/*@Override
	public List<OcppTag> getOCPPTagList(int pageSize, int pageNumber) throws ServiceException {
		try {
			List<OcppTag> returnList = securityRelationalRepository.list("OcppTag.list", new QueryParameters(null), pageSize, pageNumber, OcppTag.class);
			//securityRelationalRepository.list(queryName, queryParams, pageSize, pageNumber, resultClass)
			return returnList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}*/
	
	@Override
	public List<OcppTagRequest> getOCPPTagList() throws ServiceException, IllegalAccessException, InvocationTargetException {
		try {List<OcppTagRequest> OcppTagRequestList = new ArrayList<>();
			List<OcppTag> returnList = securityRelationalRepository.list("OcppTag.list", new QueryParameters(null), OcppTag.class);
			for(OcppTag tag : returnList){
				OcppTagRequest ocppTag = new OcppTagRequest();
				BeanUtils.copyProperties(ocppTag, tag);
				OcppTagRequestList.add(ocppTag);
			}
			return OcppTagRequestList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	public List<Map<String, Object>> getParentIdTagList() throws ServiceException {
		try {
			List <OcppTag> ocppTagList = securityRelationalRepository.list("OcppTag.ParentIdTagList", new QueryParameters(null), OcppTag.class);
			List<Map<String, Object>> parentIdTagList = new ArrayList<Map<String,Object>>();
			if(ocppTagList != null){
				
				for(OcppTag ocppTag : ocppTagList){
					Map<String, Object> map = new HashMap<String, Object>();
						map.put("id", ocppTag.getId());
						map.put("idTag", ocppTag.getIdTag());
						parentIdTagList.add(map);			
				}
			}		
			return parentIdTagList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	/*@Override
	public List<Map<String, Object>> getParentIdTagListBasedOnId(int id) throws ServiceException, NotFoundException {
		try {
			OcppTags ocppTag = securityRelationalRepository.find(id, OcppTags.class);
			//List <OcppTags> ocppTagList = securityRelationalRepository.list("OcppTags.ParentIdTagList", new QueryParameters(null), OcppTags.class);
			System.out.println(ocppTag);
			List<Map<String, Object>> parentIdTagList = new ArrayList<Map<String,Object>>();
			if(ocppTag == null){
				throw new NotFoundException("Ocpptag does not exist");
			} else {
				final Object param[][] = {{"idTag", ocppTag.getIdTag()}};
				List <OcppTags> ocppTagList = securityRelationalRepository.list("OcppTags.ParentIdTagListBasedOnId", new QueryParameters(param), OcppTags.class);
				if(ocppTagList != null){	
					for(OcppTags ocppTags : ocppTagList){
						Map<String, Object> map = new HashMap<String, Object>();
							map.put("id", ocppTags.getId());
							map.put("idTag", ocppTags.getIdTag());
							parentIdTagList.add(map);			
					}
				}			
			}				
			return parentIdTagList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}*/
	
	@Override
	@Transactional
	public OcppTagRequest updateOCPPTag(OcppTagRequest ocppTag) throws NotFoundException, ServiceException, UniqueConstraintException, IllegalAccessException, InvocationTargetException, ParseException, InvalidDataException {
		try {
			final Object [][]param = {{"idTag", ocppTag.getIdTag()}};
			OcppTag oldOcppTag = securityRelationalRepository.find("OcppTag.FindByIdTag", new QueryParameters(param), OcppTag.class);
			if(oldOcppTag == null){
				throw new NotFoundException("Ocpp tag does not exists");
			} else {
				OcppTag parentIdTag = null;	
				if(ocppTag.getParentIdTag().getIdTag() != null && ocppTag.getParentIdTag().getIdTag() != ""){
					if(ocppTag.getIdTag().equals(ocppTag.getParentIdTag().getIdTag())){
						throw new InvalidDataException("Id tag and parent id tag should not be equal");
					} else {
						final Object [][]params = {{"idTag", ocppTag.getIdTag()}};
						long count = securityRelationalRepository.find("OcppTag.listBasedOnIdTag", new QueryParameters(params), Long.class);
						if(count > 0){
							throw new InvalidDataException("A parent id tag can not become child of another id tag");
						} else {
							final Object param2[][] = {{"idTag", ocppTag.getParentIdTag().getIdTag()}};
							parentIdTag = securityRelationalRepository.find("OcppTag.FindByIdTag",new QueryParameters(param2), OcppTag.class);
							if(parentIdTag == null){
								throw new InvalidDataException("Please enter valid parent id tag");
							}
							else if(parentIdTag != null && parentIdTag.getParentIdTag() != null){
								throw new InvalidDataException("A child id tag can not become the parent of another id tag");
							}
						}
					}	
				}
				/*if(ocppTag.getExpiryDate() != null){
					long expiryTime = ocppTag.getExpiryDate().getTime();
					long currentTime = Calendar.getInstance().getTime().getTime();
					if(currentTime > expiryTime){
						throw new InvalidDataException("Expiry date should not less then current date");
					}
				}*/
				oldOcppTag.setBlocked(ocppTag.getBlocked());
				oldOcppTag.setInTransaction(ocppTag.getInTransaction());
				oldOcppTag.setNote(ocppTag.getNote());
				oldOcppTag.setParentIdTag(parentIdTag);
				oldOcppTag.setExpiryDate(ocppTag.getExpiryDate());
				OcppTag updatedOcppTag = securityRelationalRepository.update(oldOcppTag);
				BeanUtils.copyProperties(ocppTag, updatedOcppTag);
				return ocppTag;
				}			
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	
	@Override
	@Transactional
	public Response deleteOCPPTag(int ocppTagId) throws NotFoundException, ServiceException, InvalidDataException {
		try {
			Response response = new Response();
			OcppTag ocppTag = securityRelationalRepository.find(ocppTagId, OcppTag.class);
			if(ocppTag == null){
				throw new NotFoundException("Ocpp tag does not exist");
			} else { 
				final Object [][]param = {{"idTag", ocppTag.getIdTag()}};
				long count = securityRelationalRepository.find("OcppTag.listBasedOnIdTag", new QueryParameters(param), Long.class);
				if(count > 0){
					throw new InvalidDataException("This tag has relation with another id tag, so you can not delete it");
				}
				else{
					securityRelationalRepository.remove(ocppTag);
					response.setMessage("Ocpp tag successfully deleted");
					return response;
				}		
			}
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
}
