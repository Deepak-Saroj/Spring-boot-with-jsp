package com.webasto.controller;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.webasto.commons.ThreadLocalContext;
import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.BulkActiveDeactive;
import com.webasto.model.ChargePoint;
import com.webasto.model.ChargePointData;
import com.webasto.model.ChargingProfile;
import com.webasto.model.Connector;
import com.webasto.model.Response;
import com.webasto.model.ResponseList;
import com.webasto.model.UnknownChargePoint;
import com.webasto.service.ChargePointService;

@RestController
@CrossOrigin
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RequestMapping(value = "/chargepoint")
public class ChargePointController {

	private static final Logger LOG = LogManager.getLogger(ChargePointController.class);

	@Autowired
	private ChargePointService chargePointService;
	
	/** This method is used to create a new charge point 
	 * @author Manoj_Gupta
	 * @param  ChargePoint instance
	 * @return Response
	 * @throws InvalidDataException 'if charge point id will empty'
	 * @throws UniqueConstraintException 'if the charge point already exits'
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ResponseEntity<Response> createChargePoint(@RequestBody @Valid ChargePoint chargePoint) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException{
		try {
			
			LOG.debug("STARTED : createChargePoint() of ChargePointController class");
			ChargePointData newChargePoint = chargePointService.addChargingPoint(chargePoint);
			Response response = new Response();
			if(newChargePoint.getAddress() == null){
				response.setMessage("New charge point is added successfully without address");
			} else {
				response.setMessage("New charge point is added successfully");
			}
			response.setData(newChargePoint);
			LOG.debug("ENDED : createChargePoint() of ChargePointController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used to update charge point  
	 * @author Manoj_Gupta
	 * @param  ChargePoint instance
	 * @return Response 
	 * @throws InvalidDataException 'if charge point id will empty'
	 * @throws NotFoundException 'if the charge point is not exist'
	 * @throws ServiceException 'if any internal server problem' 
	 */
	@RequestMapping(value = "/edit", method = RequestMethod.PUT)
	public ResponseEntity<Response> updateChargePoint(@RequestBody @Valid ChargePoint chargePoint) throws ServiceException, NotFoundException, IllegalAccessException, InvocationTargetException, InvalidDataException{
		try {
			
			LOG.debug("STARTED : updateChargePoint() of ChargePointController class");
			ChargePointData updatedChargePoint = chargePointService.updateChargePoint(chargePoint);
			Response response = new Response();
			response.setMessage("Chargepoint updated successfully");
			response.setData(updatedChargePoint);
			LOG.debug("ENDED : updateChargePoint() of ChargePointController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used to return the charge points list  
	 * @author Manoj_Gupta
	 * @return List<ChargePoint> instance
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ResponseEntity<List<ChargePointData>> chargePointList() throws ServiceException, IllegalAccessException, InvocationTargetException{
		try {		
			LOG.debug("STARTED : chargePointsList() of ChargePointController class");
			List<ChargePointData> chargePointList = chargePointService.getChargePointList();
			LOG.debug("ENDED : chargePointsList() of ChargePointController class");
 			return ResponseEntity.ok(chargePointList);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used to fetch a charge point details 
	 * @author Manoj_Gupta
	 * @param  id
	 * @return Response 
	 * @throws NotFoundException 'if the charge point is not exist'
	 * @throws ServiceException 'if any internal server problem'
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/search/{id}", method = RequestMethod.GET)
	public ResponseEntity<Response> getChargePoint(@PathVariable int id)throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException, ParseException{
		try {
			LOG.debug("STARTED : getChargePoint() of ChargePointController class");
			ChargePointData chargePoint = chargePointService.getChargePoint(id);
			Response response = new Response();
			response.setData(chargePoint);
			response.setMessage("Chargepoint data");
			LOG.debug("ENDED : getChargePoint() of ChargePointController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used for activate or deactivate a charge point 
	 * @author Manoj_Gupta
	 * @param  ChargePointData
	 * @return Response 
	 * @throws NotFoundException 'if the charge point is not exist'
	 * @throws ServiceException 'if any internal server problem'
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 */
	@RequestMapping(value = "/activate", method = RequestMethod.PUT)
	public ResponseEntity<Response> activateOrDeactivateChargePoint(@RequestBody ChargePointData chargePoint ) throws NotFoundException, IllegalAccessException, InvocationTargetException, ServiceException{
		try {
			System.out.println(1);
			List chargePointList = chargePointService.activateOrDeactivateChargePoint(chargePoint);
			Response response = new Response();
			/*if(updatedChargePoint.getActive() == 1){
				response.setMessage("Chargepoint activated successfully");
			} else {
				response.setMessage("Chargepoint deactivated successfully");
			}*/
			response.setMessage("Charge point list");
			response.setData(chargePointList);
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/bulkactivate", method = RequestMethod.PUT)
	public ResponseEntity<Response> activateOrDeactivateBulkChargePoint(@RequestBody BulkActiveDeactive  bulkActiveDeactiveList) throws NotFoundException, IllegalAccessException, InvocationTargetException, ServiceException{
		try {
			System.out.println(bulkActiveDeactiveList.getId());
			List updatedChargePoint = chargePointService.activateOrDeactivateBulkChargePoint(bulkActiveDeactiveList);
			Response response = new Response();
			response.setMessage("Updated charge point list");
		
			response.setData(updatedChargePoint);
			return ResponseEntity.ok(response);
		} catch (Exception se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	
	/** This method is used to delete a particular charge point  
	 * @author Manoj_Gupta
	 * @param  id
	 * @return Response 
	 * @throws NotFoundException 'if the charge point is not exist'
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Response> deleteChargePoint(@PathVariable int id) throws ServiceException, NotFoundException{
		try {
			LOG.debug("STARTED : deleteChargePoint() of ChargePointController class");
			Response response = chargePointService.deleteChargePoint(id);
			response.setMessage("Chargepoint is deleted successfully");
			LOG.debug("ENDED : deleteChargePoint() of ChargePointController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used to delete bulk charge point  
	 * @author Manoj_Gupta
	 * @param  chargePointIds
	 * @return Response 
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public ResponseEntity<Response> deleteChargePoints(@RequestBody List<Integer> chargePointIds) throws ServiceException, NotFoundException{
		try {
			System.out.println(chargePointIds);
			LOG.debug("STARTED : deleteChargePoint() of ChargePointController class");
			Response response = chargePointService.deleteChargePoints(chargePointIds);
			LOG.debug("ENDED : deleteChargePoint() of ChargePointController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	

	
	/** This method is used to return the list of charging profile  
	 * @author Manoj_Gupta
	 * @return List<ChargingProfile> instance
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/chargingprofiles/search", method = RequestMethod.GET)
	public ResponseEntity<List<ChargingProfile>> getChargingProfileList() throws ServiceException{
		try {
			LOG.debug("STARTED : getChargingProfile() of ChargePointController class");
			List<ChargingProfile> chargeProfileList = chargePointService.getChargingProfileList();
			LOG.debug("ENDED : getChargingProfile() of ChargePointController class");
			return ResponseEntity.ok(chargeProfileList);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used to fetch the list of unknown charge points  
	 * @author Manoj_Gupta
	 * @return List<UnknownChargePoint> instance
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/unknown/search", method = RequestMethod.GET)
	public ResponseEntity<ResponseList> getUnknownChargePointList() throws ServiceException{
		try {
			List list = chargePointService.getUnknownChargePointList();
			ResponseList response = new ResponseList();
			response.setMessage("Unknown charge points list");
			response.setData(list);
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	@RequestMapping(value = "/chargingprofiles/search/{chargingProfileId}", method = RequestMethod.GET)
	public void getChargingProfile(@PathVariable int chargingProfileId){
		try {
			chargePointService.getChargingProfile(chargingProfileId);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/chargingprofiles/add", method = RequestMethod.POST)
	public void addChargingProfile(@RequestBody ChargingProfile chargingProfile){
		try {
			chargePointService.addChargingProfile(chargingProfile);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/chargingprofiles", method = RequestMethod.PUT)
	public void updataChargingProfile(@RequestBody ChargingProfile chargingProfile){
		try {
			chargePointService.updateChargingProfile(chargingProfile);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/chargingprofiles/{chargingProfileId}", method = RequestMethod.DELETE)
	public void deleteChargingProfile(@PathVariable int chargingProfileId){
		try {
			chargePointService.deleteChargingProfile(chargingProfileId);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/status/search", method = RequestMethod.GET)
	public void getChargePointStatusList(){
		try {
			chargePointService.chargePointStatus();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/connector/status/search", method = RequestMethod.GET)
	public void getConnectorStatusList(){
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@RequestMapping(value = "/connector/search")
	public ResponseEntity<List<String>> getConnectors(@RequestBody List<String> cplist) throws ServiceException{
		try {
			return ResponseEntity.ok(chargePointService.getConnector(cplist, 1));
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException();
		}
	}
	
}
