package com.webasto.model;

public class BulkChargeResponse {

	public String status;
	private String downloadLink;
	
	public BulkChargeResponse(String status, String downloadLink) {
		super();
		this.status = status;
		this.downloadLink = downloadLink;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDownloadLink() {
		return downloadLink;
	}
	public void setDownloadLink(String downloadLink) {
		this.downloadLink = downloadLink;
	}
	
	
}
