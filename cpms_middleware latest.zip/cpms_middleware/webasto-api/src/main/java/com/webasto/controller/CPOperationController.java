package com.webasto.controller;

import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.ChargePointOperation;
import com.webasto.model.ChargePointOperationLog;
import com.webasto.service.CPOperationControllerService;

@CrossOrigin
@RestController
@RequestMapping(value = "/cp")
public class CPOperationController {
	@Autowired
	private CPOperationControllerService chargePointOPService;
	
	private static final Logger LOG = LogManager.getLogger(CPMSOperationController.class);
	private Object[] response = null;
	@PostMapping(value = "/operations")
	public ResponseEntity<Object[]> performOperation(@RequestBody String data) throws JsonProcessingException {
		LOG.debug("STARTED: CP perform operations");
		LOG.debug("Acctual Request "+data);
		Integer type=null;
		String uuid=null;
		String requestType=null;
		JSONObject payload=null;
		try {

			JSONArray dataArray = new JSONArray(data);
			type=dataArray.getInt(0);
			uuid=dataArray.getString(1);
			requestType=dataArray.getString(2);
			payload=dataArray.getJSONObject(3);

			System.out.println("uuid "+uuid);
			System.out.println("requestType "+requestType);
			System.out.println("payload "+payload);
			
			ChargePointOperation cpo=new ChargePointOperation();
			cpo.setId(uuid);
			cpo.setName(requestType);
		    chargePointOPService.addCPOperation(cpo);
		    
		    ChargePointOperationLog cpol=new ChargePointOperationLog();
		    cpol.setId(uuid);
		    cpol.setType(type);
		    cpol.setMsg(payload.toString());
		    chargePointOPService.addCPOperationLog(cpol);

			String[] responseData = { "3", uuid,"Request is Processed Successfully"};
			this.response= responseData;

		}catch(Exception e) {
			e.printStackTrace();
			String[] responseData = { "4", uuid,"Could not able to process the Request.Please Contact Adminstrator","Could not able to process the Request.Please Contact Adminstrator"};
			this.response= responseData;
		}
		LOG.debug("Response " + Arrays.toString(this.response));		
		return ResponseEntity.ok(this.response);

	}
	
	@RequestMapping(value = "/operations/logList/{date}", method = RequestMethod.GET)
	public ResponseEntity<List<ChargePointOperation>> getChargePointOperationsList(@PathVariable String date) throws ServiceException{
		try {
			LOG.debug("STARTED : getChargPoint Operations");
			//2020-01-06
			List<ChargePointOperation> cplist = chargePointOPService.getChargePointOperationList(date);
			
			/*
			 * for(Object obj:chargeProfileList) { ChargePointOperation cpo=new
			 * ChargePointOperation(); //List xf = (List)obj;
			 * //cpo.setName(xf.get(0).toString()); //cplist.add(cpo); }
			 */
			LOG.debug("ENDED : getChargingProfile() of ChargePointController class");
			return ResponseEntity.ok(cplist);
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.error(e);
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/operations/logList/{date}/{type}", method = RequestMethod.GET)
	public ResponseEntity<List<ChargePointOperationLog>> getChargePointOperationsLogsList(@PathVariable String date,@PathVariable String type) throws ServiceException{
		try {
			LOG.debug("STARTED : getChargPoint Operations");
			//2020-01-06
			List<ChargePointOperationLog> cplist = chargePointOPService.getChargePointOperationLogsList(date,type);
			
			/*
			 * for(Object obj:chargeProfileList) { ChargePointOperation cpo=new
			 * ChargePointOperation(); //List xf = (List)obj;
			 * //cpo.setName(xf.get(0).toString()); //cplist.add(cpo); }
			 */
			LOG.debug("ENDED : getChargingProfile() of ChargePointController class");
			return ResponseEntity.ok(cplist);
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.error(e);
			throw new ServiceException("Internal server error");
		}
	}
}