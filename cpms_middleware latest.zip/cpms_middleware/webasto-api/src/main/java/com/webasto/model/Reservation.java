package com.webasto.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//@Entity
@Table(name = "reservation")
public class Reservation {

	@Id
	@Column(name = "reservation_pk")
	private int reservationId;
	
	@Column(name = "connector_pk")
	private Integer connectorPk;
	
	@Column(name = "transaction_pk")
	private Integer transactionPk;
	
	@Column(name = "start_datetime")
	private Date startDateTime;
	
	@Column(name = "expiry_datetime")
	private Date expiryDateTime;
	
	@Column(name = "status")
	private String status;	
	

}
