package com.webasto.exception;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.webasto.commons.sql.exception.AuthorizationException;
import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.UniqueConstraintException;

@ControllerAdvice("com.webasto")
public class APIGlobalException extends ResponseEntityExceptionHandler {

	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<ExceptionResponse> handleNotFoundException(NotFoundException ex, WebRequest request) {
		ExceptionResponse response = new ExceptionResponse();

		//response.setMessage(ex.getLocalizedMessage());
		//response.setException(ex.toString());
		List<String> errorList = new ArrayList<String>();
		errorList.add(ex.getLocalizedMessage());
		response.setErrorList(errorList);
		//response.setPath(request.getContextPath());
		response.setStatus(HttpStatus.NOT_FOUND.toString());
		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(SQLException.class)
	public ResponseEntity<ExceptionResponse> handleSQLException(SQLException ex, WebRequest request) {
		ExceptionResponse response = new ExceptionResponse();

		//response.setMessage(ex.getLocalizedMessage());
		List<String> errorList = new ArrayList<String>();
		errorList.add(ex.getLocalizedMessage());
		response.setErrorList(errorList);
		//response.setException(ex.toString());
		//response.setPath(request.getContextPath());
		response.setStatus(HttpStatus.BAD_REQUEST.toString());

		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(TransactionSystemException.class)
	public ResponseEntity<ExceptionResponse> handleTransactionSystemException(TransactionSystemException ex,
			WebRequest request) {
		ExceptionResponse response = new ExceptionResponse();
		Throwable t = ex.getApplicationException().getCause();
		List<String> errorList = new ArrayList<String>();
		errorList.add(ex.getLocalizedMessage());
		response.setErrorList(errorList);
		//response.setMessage(t.getMessage());
		//response.setException(t.toString());
		//response.setPath(request.getContextPath());

		response.setStatus(HttpStatus.BAD_REQUEST.toString());

		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(UniqueConstraintException.class)
	protected ResponseEntity<ExceptionResponse> handleUniqueConstraintException(UniqueConstraintException ex,
			 WebRequest request) {
		ExceptionResponse response = new ExceptionResponse();

		//response.setMessage(ex.getLocalizedMessage());
		List<String> errorList = new ArrayList<String>();
		errorList.add(ex.getLocalizedMessage());
		response.setErrorList(errorList);
		//response.setException(ex.toString());
		//response.setPath(request.getContextPath());
		response.setStatus(HttpStatus.CONFLICT.toString());

		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.CONFLICT);
	}

	@ExceptionHandler(InvalidDataException.class)
	protected ResponseEntity<ExceptionResponse> handleInvalidDataException(InvalidDataException ex,  WebRequest request) {
		ExceptionResponse response = new ExceptionResponse();

		//response.setMessage(ex.getLocalizedMessage());
		List<String> errorList = new ArrayList<String>();
		errorList.add(ex.getLocalizedMessage());
		response.setErrorList(errorList);
		//response.setException(ex.toString());
		//response.setPath(request.getContextPath());
		response.setStatus(HttpStatus.BAD_REQUEST.toString());

		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		ExceptionResponse response = new ExceptionResponse();
		List<FieldError> error =  ex.getBindingResult().getFieldErrors();
	//.	response.setMessage(error.get(0).getDefaultMessage());
		//response.setMessage("Invalid input data");
		
		response.setErrorList(ex.getBindingResult().getFieldErrors().stream().map(ObjectError::getDefaultMessage)
			.collect(Collectors.toList()));
		//response.setException(ex.toString());
		//response.setPath(request.getContextPath());
		response.setStatus(HttpStatus.BAD_REQUEST.toString());

		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler(Exception.class)

	public ResponseEntity<ExceptionResponse> handleAllExceptions(Exception ex, WebRequest request) {
		ExceptionResponse response = new ExceptionResponse();
		ex.printStackTrace();
		//response.setMessage("Internal server error");
		List<String> errorList = new ArrayList<String>();
		errorList.add("Internal server error");
		response.setErrorList(errorList);
		//response.setException(ex.toString());
		//response.setPath(request.getContextPath());
		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(AuthorizationException.class)
	public ResponseEntity<ExceptionResponse> handleAuthorizationException(AuthorizationException ex, WebRequest request){
		ExceptionResponse response = new ExceptionResponse();
		ex.printStackTrace();
		//response.setMessage("Access not authorized. Please contact your ArriaLife administrator.");
		List<String> errorList = new ArrayList<String>();
		errorList.add("Access not authorized. Please contact your ArriaLife administrator.");
	//	response.setException(ex.toString());
		//response.setPath(request.getContextPath());
		response.setStatus(HttpStatus.BAD_REQUEST.toString());

		return new ResponseEntity<ExceptionResponse>(response, HttpStatus.BAD_REQUEST);
	}


}
