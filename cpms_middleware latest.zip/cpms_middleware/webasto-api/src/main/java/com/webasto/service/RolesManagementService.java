package com.webasto.service;

import java.util.List;

import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.Response;
import com.webasto.model.Role;

public interface RolesManagementService {

	public Role addRole(Role role)throws ServiceException, UniqueConstraintException;
	public Role getRole(int roleId) throws NotFoundException, ServiceException;
	public List<Role> roleList()throws ServiceException;
	public Response deleteRole(int roleId)throws NotFoundException, ServiceException;
	public Role updateRole(Role role)throws NotFoundException, ServiceException;
}
