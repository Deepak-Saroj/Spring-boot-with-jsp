			package com.webasto.controller;
			
			import java.util.UUID;
			
			import org.apache.logging.log4j.LogManager;
			import org.apache.logging.log4j.Logger;
			import org.json.JSONArray;
			import org.json.JSONObject;
			import org.springframework.beans.factory.annotation.Autowired;
			import org.springframework.http.ResponseEntity;
			import org.springframework.web.bind.annotation.CrossOrigin;
			import org.springframework.web.bind.annotation.PostMapping;
			import org.springframework.web.bind.annotation.RequestBody;
			import org.springframework.web.bind.annotation.RequestMapping;
			import org.springframework.web.bind.annotation.RestController;
			
			import com.fasterxml.jackson.core.JsonProcessingException;
			import com.fasterxml.jackson.databind.ObjectMapper;
			
			import io.vertx.core.http.HttpClient;
			import io.vertx.core.http.WebSocket;
			import io.vertx.core.http.WebSocketConnectOptions;
			import io.vertx.core.json.JsonObject;
			
			@CrossOrigin
			@RestController
			@RequestMapping(value = "/csdgdg")
			public class OperationController {
				
				private static final Logger LOG = LogManager.getLogger(OperationController.class);
			
			private Object[] response = null;
			
			private static WebSocket ws=null;
			
			@Autowired
			private WebSocketConnectOptions options;
			@Autowired
			private HttpClient client;
			
			@PostMapping(value = "/operations")
			public ResponseEntity<Object[]> performOperation(@RequestBody String data) throws JsonProcessingException {
				LOG.debug("STARTED: perform operation");
				System.out.println("start");
				String uuid="";
			try {
			
					ObjectMapper mapper = new ObjectMapper();
					//String webSocketMsg = mapper.writeValueAsString(data);
					
					JSONObject jsonObject = new JSONObject(data);
					this.response=null;
					System.out.println("Acctual request "+data);
					LOG.debug("Acctual request "+data);
					uuid=UUID.randomUUID().toString();
					String type = jsonObject.getString("type").toString();
					JSONObject payload = jsonObject.getJSONObject("payload");
					JSONArray cpList = jsonObject.getJSONArray("cplist");
					
					
					// perform validation that type and cplist is not empty, payload is valid with json schema
					String[] newPayload = { "2",uuid , cpList.toString(),type, payload.toString()};
					JSONArray arr = new JSONArray();
					arr.put(2);
					arr.put(uuid);
					arr.put(cpList);
					arr.put(type);
					arr.put(payload);
					
					
					
					String webSocketMsg = arr.toString();
					System.out.println("Web Socket Msg"+webSocketMsg);
					LOG.debug("Web Socket Msg"+webSocketMsg);
					
					if(ws==null){
						System.out.println("ws client : 1" +ws);
						client.webSocket(options, handler -> {
							
							 ws = handler.result();
							
							ws.textMessageHandler(textHandler -> {
							
							System.out.println("Response " + textHandler.toString());
							LOG.debug("Response " + textHandler.toString());
					try {
					this.response = mapper.readValue(textHandler.toString(), Object[].class);
							
							Object id = this.response[0];
							System.out.println("response id " + id.toString());
							
					} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
					});
					
					ws.writeFinalTextFrame(webSocketMsg);
					System.out.println(handler.succeeded());
					LOG.debug(handler.succeeded());
					
					});
					}else{
						System.out.println("ws client : 2" +ws);
						ws.writeFinalTextFrame(webSocketMsg);
						ws.textMessageHandler(textHandler -> {
							
							System.out.println("Response " + textHandler.toString());
							LOG.debug("Response " + textHandler.toString());
					try {
					this.response = mapper.readValue(textHandler.toString(), Object[].class);
							
							Object id = this.response[0];
							System.out.println("response id " + id.toString());
							
					} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					LOG.error(e);
					}
					});
					
					
					}
										
			
			if (this.response== null) {
				
			String[] responseData = { "3", uuid,"Request is Processed Successfully"};
			this.response= responseData;
			}
			
			}catch(Exception e) {
				LOG.error(e);
			String[] responseData = { "4", uuid,"Could not able to process the Request.Please Contact Adminstrator","Could not able to process the Request.Please Contact Adminstrator"};
			this.response= responseData;
			}
			
			
			return ResponseEntity.ok(this.response);
			
			}
			}