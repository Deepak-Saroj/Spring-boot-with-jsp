package com.webasto.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "user")
@NamedQueries(value = {@NamedQuery(name = "UserLogin.findByuserName", query ="SELECT c FROM UserLogin c WHERE c.userName = :userName"),
					   @NamedQuery(name = "UserLogin.list", query ="SELECT c FROM UserLogin c ")})
public class UserLogin {

	@Id
	@GeneratedValue	( strategy = GenerationType.IDENTITY )
	@Column(name = "id")
	private int id;
	
	@Pattern(regexp = "^$|\\w+([-+.]\\w+)*@(\\w+\\.com)", message = "Please enter a valid email format")
	@NotNull
	@Column(name = "username", nullable = false, unique = true)
	private String userName;
	
	//@Pattern(regexp ="^.{1,}$", message = "Password is mandatory")
	@Column(name = "password", nullable = false)
	@NotNull
	private String password;
	
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "active", columnDefinition = "tinyint(1) unsigned NOT NULL")
	private Short active;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Short getActive() {
		return active;
	}

	public void setActive(Short active) {
		this.active = active;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "UserLogin [id=" + id + ", userName=" + userName + ", password=" + password + ", name=" + name
				+ ", active=" + active + "]";
	}
	
	
	
	
}
