package com.webasto.service;

import java.util.List;

import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.Transaction;

public interface TransactionService {

	public List<Transaction> getTransactionList()throws ServiceException;
}
