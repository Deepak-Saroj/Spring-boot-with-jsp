package com.webasto.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.Configuration;

@Service
public class ConfigurationServiceImpl implements ConfigurationService {

	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;
	
	@Override
	@Transactional
	public Configuration updateConfiguration(Configuration configuration) throws ServiceException {
		try {
			Configuration oldCofiguration = securityRelationalRepository.find(1, Configuration.class);
			if(oldCofiguration != null){
				oldCofiguration.setConfigValue(configuration.getConfigValue());
				System.out.println(oldCofiguration.getId());
				oldCofiguration = securityRelationalRepository.update(oldCofiguration);
			}
			return oldCofiguration;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	@Transactional
	public Configuration updateConfigurations(Map<String, Object> configuration) throws ServiceException {
		try {
			Set<String> keySet = configuration.keySet();
	        for(String key : keySet){
	        	final Object params[][] = {{"configName", key},{"configValue", configuration.get(key)}};
	        	securityRelationalRepository.remove("Configuration.Update", new QueryParameters(params));
	        	System.out.println(key + " "+configuration.get(key) );
	        }
			return null;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	public Configuration getConfiguration() throws ServiceException {
		try {
			Configuration configuration = securityRelationalRepository.find("Configuration.getByname", new QueryParameters(null), Configuration.class);
			
			return configuration;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	@Override
	public List<Configuration> getConfigurations() throws ServiceException {
		try {
			List<Configuration> configuration = securityRelationalRepository.list("Configuration.List",new QueryParameters(null), Configuration.class);
			Map<String, Object> configuratios = new HashMap<String, Object>();
			for(Configuration con : configuration){
				configuratios.put(con.getConfigName(), con.getConfigValue());
			}
			System.out.println(configuratios);
			return configuration;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
}
