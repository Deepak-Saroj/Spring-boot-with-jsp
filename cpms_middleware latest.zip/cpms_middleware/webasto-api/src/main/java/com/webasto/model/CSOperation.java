package com.webasto.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "cs_operation")

@NamedQueries(value = {
		   @NamedQuery(name = "CSOperation.list", query = "SELECT cso FROM CSOperation cso")
		   })
public class CSOperation  implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "id", unique = true, nullable = false)
	private String id;
	
	@Column(name = "name",  nullable = false)
	@NotNull(message = "Operation name is required")
	private String name;
	
	@CreationTimestamp
	@JsonFormat(pattern="MM-dd-yyyy HH:mm")
	@Column(name = "created_time", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date createdTime;
	
	
	@Transient
	private List<Object> response;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public List<Object> getResponse() {
		return response;
	}

	public void setResponse(List<Object> response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "CSOperation [id=" + id + ", name=" + name + ", createdTime=" + createdTime + ", response=" + response
				+ "]";
	}
	
	
}
