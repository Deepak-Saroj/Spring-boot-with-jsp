package com.webasto.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "cs_operation_log")
@NamedQueries(value = {@NamedQuery(name = "CSOperationLog.ListBasedOnId", query = "SELECT csol FROM CSOperationLog csol WHERE csol.id = :id")})
public class CSOperationLog  implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "id",  nullable = false)
	private String id;
	
	@Column(name = "type",  nullable = false)
	@NotNull(message = "Type is required")
	private Integer type;
	
	@Column(name = "msg",  nullable = false)
	@NotNull(message = "Message is required")
	private String msg;
	
	@Transient
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	@CreationTimestamp
	@JsonFormat(pattern="MM-dd-yyyy HH:mm")
	@Column(name = "created_time", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date createdTime;
}
