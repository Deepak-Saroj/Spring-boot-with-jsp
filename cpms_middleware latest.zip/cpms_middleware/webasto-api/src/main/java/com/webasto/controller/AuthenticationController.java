package com.webasto.controller;

import java.lang.reflect.InvocationTargetException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.InvalidUserException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.DashboardResponse;
import com.webasto.model.PasswordUpdate;
import com.webasto.model.Response;
import com.webasto.model.User;
import com.webasto.model.UserData;
import com.webasto.model.UserLogin;
import com.webasto.service.AuthenticationService;

@RestController
@CrossOrigin
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RequestMapping("/system/authentication")
public class AuthenticationController {
	
	private static final Logger LOG = LogManager.getLogger(AuthenticationController.class);

	@Value("${spring.mail.username}")
	private String username;
	
	@Value("${spring.mail.password}")
	private String password;
	
	@Value("${spring.reactUrl}")
	private String reactUrl;
	
	@Autowired
	private AuthenticationService authenticationService;
	
	
	/** This method is used to verify the credential of user based on user emailId and password 
	 * @author Manoj_Gupta
	 * @param login Login instance
	 * @return UserData instance 
	 * @throws ServiceException 'if any internal server problem'
	 * @throws NotFoundException 'if the user is not present in database or EmailID and password is not correct'
	 * @throws InvalidDataException 'if email id and password is not in valid format'
	 * @throws NoSuchAlgorithmException 
	 */
	/*@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<Response> login(@RequestBody @Valid Login login, HttpServletRequest req) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException, InvalidDataException, NoSuchAlgorithmException{
		try {
			LOG.debug("STARTED : login() of AuthenticationController class");
			
			//MessageDigest md = MessageDigest.getInstance("MD5"); 
			 String md5 = null;
            // digest() method is called to calculate message digest 
            //  of an input digest() return array of byte 
           // byte[] messageDigest = md.digest("manoj".getBytes()); 
            //// Convert message digest into hex value 
            //125622298804500554314291242845197547577
           // String hashtext = no.toString();
           // MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(compare.getBytes());
            byte[] digest = md.digest();
            md5 = new BigInteger(1, digest()).toString(16);
          //  System.out.println(hashtext);
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update("manoj".getBytes());
            byte[] digest = md.digest();
            md5 = new BigInteger(1, digest).toString();
            System.out.println(md5.equals("125622298804500554314291242845197547577"));
            //md5.equals(orig);
            //return md5.equals(orig);
            UserData user = authenticationService.login(login);
			Response response = new Response();
			response.setMessage("User authenticated successfully");
			response.setData(user);
			System.out.println(user);
			LOG.debug("ENDED : login() of AuthenticationController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error("EXCEPTION : \"Internal server error \"Catch block executed of login() of AuthenticationController class" );
			throw new ServiceException("internal server error");
		}
	}*/
	
	/** This method is used to verify the credential of user based on user emailId and password 
	 * @author Manoj_Gupta
	 * @param  UserLogin instance
	 * @return UserLogin instance 
	 * @throws ServiceException 'if any internal server problem'
	 * @throws NotFoundException 'if the user is not present in database or EmailID and password is not correct'
	 * @throws InvalidDataException 'if email id and password is not in valid format'
	 * @throws NoSuchAlgorithmException 
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<UserLogin> login(@RequestBody @Valid UserLogin login) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException, InvalidDataException, NoSuchAlgorithmException{
	try {		
		LOG.debug("STARTED : login() of AuthenticationController class");
		UserLogin user=authenticationService.getUserLogin(login);
		user.setPassword("");
		LOG.debug("ENDED : login() of AuthenticationController class");
		return ResponseEntity.ok(user);
	} catch (ServiceException se) {
		LOG.error(se);
		throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used to verify the user emailID and it will send a email to user email address with a token to change the password 
	 * @author Manoj_Gupta
	 * @param  PasswordUpdate instance 
	 * @return Response instance
	 * @throws InvalidDataException 'if data will not be in proper format'
	 * @throws NotFoundException 'if the user is not present in database or EmailID and password is not correct'
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/forgetpassword", method = RequestMethod.POST)
	public ResponseEntity<Response> forgetPassword(@RequestBody @Valid PasswordUpdate forgetPassword) throws NotFoundException, ServiceException, InvalidDataException, InvalidUserException,  AddressException, MessagingException{
		try {
			LOG.debug("STARTED : forgetPassword() of AuthenticationController class");
			System.out.println(1);
			User user = authenticationService.forgetPassword(forgetPassword);
			sendMail(user);
			System.out.println("sending message");
			Response response = new Response();
			response.setMessage("success");
			LOG.debug("ENDED : forgetPassword() of AuthenticationController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("internal server error");
		}
	}
	
	/** This method is used to verify the token  
	 * @author Manoj_Gupta
	 * @param  token 
	 * @return UserData details
	 * @throws InvalidDataException 'if the link has expired'
	 * @throws NotFoundException 'if the token is invalid'
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/verifytoken/{token}", method = RequestMethod.GET)
	public ResponseEntity<Response> verifyToken(@PathVariable String token) throws ServiceException, InvalidDataException, NotFoundException{
		try {
			LOG.debug("STARTED : verifyToken() of AuthenticationController class");
			System.out.println("verify token");
			Response response = new Response();
			authenticationService.verifyToken(token);
			response.setMessage("success");
			LOG.debug("ENDED : verifyToken() of AuthenticationController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("internal server error");
		}
	}
		
	/** This method is used to update the user password  
	 * @author Manoj_Gupta
	 * @param  PasswordUpdate instance
	 * @return UserData details
	 * @throws InvalidDataException 'if the link has expired or if the new password and old password will not match'
	 * @throws NotFoundException 'if the token is invalid'
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/resetpassword", method = RequestMethod.PUT)
	public ResponseEntity<UserData> resetPassword(@RequestBody PasswordUpdate password) throws ServiceException, NotFoundException, IllegalAccessException, InvocationTargetException, InvalidDataException{
		try {
			LOG.debug("STARTED : resetPassword() of AuthenticationController class");
			System.out.println("updata");
			UserData data = authenticationService.updatePassword(password);
			LOG.debug("ENDED : resetPassword() of AuthenticationController class");
			return ResponseEntity.ok(data);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("internal server error");
		}
	}
	
	private void sendMail(User user) throws AddressException, MessagingException{
		LOG.debug("STARTED : sendMail() of AuthenticationController class");

		Properties props = new Properties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});
		MimeMessage msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress(username, false));

		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user.getEmail()));
		msg.setSubject("Reset Password Link");
		//hard coded html due to not finding resource folder for temporary purpose
		msg.setContent("<!DOCTYPE html>\r" + 
				"<html>\r" + 
				"<head>\r" + 
				"<style>\r" + 
				".button {\r" + 
				"  background-color: #23a465;\r\n" + 
				"  border: none;\r" + 
				"  color: white;\r" + 
				"  padding: 15px 32px;\r" + 
				"  text-align: center;\r" + 
				"  text-decoration: none;\r" + 
				"  display: inline-block;\r" + 
				"  font-size: 16px;\r\n" + 
				"  margin: 10px 2px;\r\n" + 
				"  cursor: pointer;\r\n" + 
				"}\r\n" + 
				"</style>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"Click 'Here' to reset password page and 'Change Password'  ( 'Here' link should be redirected to reset password)\r\n" +
				"\r\n" + 
				"\r\n" + 
				"<a href="+reactUrl+"/"+user.getToken()+"/resetpassword>Reset Password</a>.\r\n" +
				
				"<br><b> Note :</b> Please do not reply to this email, Emails sent to this address will not be answered.\r\n"+
				"</body>\r\n" + 
				"</html>","text/html");
		msg.setSentDate(new Date());
		// sends the e-mail
		Transport.send(msg);
		LOG.debug("ENDED : sendMail() of AuthenticationController class");	
	}
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ResponseEntity<Response> dashboard() throws ServiceException{
		try {
			DashboardResponse resp = authenticationService.deshboard();
			Response response = new Response();
			response.setMessage("No of charge points");
			response.setData(resp);
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
}
