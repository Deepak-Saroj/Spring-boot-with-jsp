package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.OcppTag;
import com.webasto.model.OcppTagRequest;
import com.webasto.model.OcppTagResponse;
import com.webasto.model.Response;

public interface OCPPTagService {
	public OcppTagRequest createOCPPTag(OcppTagRequest ocppTag)throws UniqueConstraintException, ServiceException, InvalidDataException, IllegalAccessException, InvocationTargetException, ParseException;
	public OcppTagRequest getOCPPTag(int ocppTagId)throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException;
	public List<OcppTagRequest> getOCPPTagList()throws ServiceException, IllegalAccessException, InvocationTargetException;
	public Response deleteOCPPTag(int ocppTag)throws NotFoundException, ServiceException, InvalidDataException;
	public OcppTagRequest updateOCPPTag(OcppTagRequest ocppTag)throws NotFoundException, ServiceException, UniqueConstraintException, IllegalAccessException, InvocationTargetException, ParseException, InvalidDataException;
	public List<Map<String, Object>> getParentIdTagList()throws ServiceException;
	//public List<Map<String, Object>> getParentIdTagListBasedOnId(int id) throws ServiceException, NotFoundException ;
	

}
