package com.webasto.service;

import java.util.List;
import java.util.Map;

import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.Configuration;

public interface ConfigurationService {

	public Configuration updateConfiguration(Configuration configuration)throws ServiceException, PersistenceException;
	public Configuration getConfiguration()throws ServiceException;
	Configuration updateConfigurations(Map<String, Object> configuration) throws ServiceException;
	public List<Configuration> getConfigurations() throws ServiceException ;
}
