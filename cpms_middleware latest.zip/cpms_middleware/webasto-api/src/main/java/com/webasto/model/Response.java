package com.webasto.model;

import java.util.List;
import java.util.Map;

public class Response {

	private String message;
	private Object data;
	//private List<Object> dataList;
	//private Map<String, Object> responseBody;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	/*public Map<String, Object> getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(Map<String, Object> responseBody) {
		this.responseBody = responseBody;
	}
*/
	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
/*
	public List<Object> getDataList() {
		return dataList;
	}

	public void setDataList(List<Object> dataList) {
		this.dataList = dataList;
	}*/
	
	
}
