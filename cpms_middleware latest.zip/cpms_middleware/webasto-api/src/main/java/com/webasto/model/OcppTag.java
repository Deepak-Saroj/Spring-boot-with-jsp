package com.webasto.model;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Date;
import java.util.TimeZone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.webasto.commons.ThreadLocalContext;

@Entity
@Table(name = "ocpp_tag")
@NamedQueries(value = {@NamedQuery(name = "OcppTag.FindByIdTag", query = "SELECT o from OcppTag o where o.idTag = :idTag"),
					   @NamedQuery(name = "OcppTag.list", query = "SELECT o from OcppTag o"),
					   @NamedQuery(name = "OcppTag.ParentIdTagList", query = "SELECT c FROM OcppTag c WHERE c.parentIdTag IS NULL"),
					   @NamedQuery(name = "OcppTag.listBasedOnIdTag", query = "SELECT count(*) FROM OcppTag c WHERE c.parentIdTag.idTag = :idTag")})
public class OcppTag implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "id_tag", unique = true)
	@NotNull(message = "ID Tag is required")
	@Pattern(regexp = "^.{1,20}$", message= "ID Tag is required and length should be upto 20 character")
	private String idTag;
	 
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "parent_id_tag" ,referencedColumnName ="id_tag")
	private OcppTag parentIdTag;
		
	@JsonFormat(pattern="MM-dd-yyyy HH:mm")
	@Column(name = "expiry_date", columnDefinition = "timestamp(6) NULL DEFAULT NULL")
	private LocalDateTime expiryDate;
	
	@Column(name = "blocked", columnDefinition = "tinyint(1) unsigned NOT NULL")
	//@NotNull(message = "Blocked field value is required")
	private Short blocked;
	
	@Column(name = "in_transaction", columnDefinition = "tinyint(1) unsigned NOT NULL")
	//@NotNull(message = "In Transaction field value is required")
	private Short inTransaction;

	@Column(name = "note", columnDefinition = "mediumtext")
	private String note;
	
	@Transient
	private String expDate;
	
	
	public String getExpDate() {
		if(expiryDate != null){
			SimpleDateFormat dateFormat = (SimpleDateFormat)ThreadLocalContext.get(ThreadLocalContext.DATE_FORMAT);
	 		expDate = dateFormat.format(Date.from(expiryDate.atZone( ZoneId.of("UTC")).toInstant()));
		}
		return expDate;
	}
	
	public String getIdTag() {
		return idTag;
	}
	public void setIdTag(String idTag) {
		this.idTag = idTag;
	}
	public OcppTag getParentIdTag() {
		return parentIdTag;
	}
	public void setParentIdTag(OcppTag parentIdTag) {
		this.parentIdTag = parentIdTag;
	}

	public LocalDateTime getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDateTime expiryDate) throws ParseException {
		this.expiryDate = expiryDate;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Short getBlocked() {
		return blocked;
	}
	public void setBlocked(Short blocked) {
		this.blocked = blocked;
	}
	public Short getInTransaction() {
		return inTransaction;
	}
	public void setInTransaction(Short inTransaction) {
		this.inTransaction = inTransaction;
	}
	
}
