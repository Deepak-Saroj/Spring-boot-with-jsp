package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.webasto.commons.ThreadLocalContext;
import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.InvalidUserException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.DashboardResponse;
import com.webasto.model.Login;
import com.webasto.model.PasswordUpdate;
import com.webasto.model.Role;
import com.webasto.model.User;
import com.webasto.model.UserData;
import com.webasto.model.UserLogin;
import com.webasto.model.UserRole;

@Service
public class AuthenticationServiceImpl implements AuthenticationService{
	
	private static final Logger LOG = LogManager.getLogger(AuthenticationServiceImpl.class);

	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
		
	public AuthenticationServiceImpl() {
		System.out.println("AuthenticationServiceImpl.AuthenticationServiceImpl()");
	}
	
	@Override
	public UserData login(Login login) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException {
		try {
			LOG.debug("STARTED : login() of AuthenticationServiceImpl class");
			Object param[][] = {{"email", login.getEmail()}};
			System.out.println("beford user");
			User user = securityRelationalRepository.find("User.findByEmail", new QueryParameters(param), User.class);
			if(user == null){
				LOG.error("EXCEPTION : \"Please enter a valid email and password \" raised in login() of AuthenticationServiceImpl class" );
				throw new NotFoundException("Please enter a valid email and password");
			} else if (!bCryptPasswordEncoder.matches(login.getPassword(), user.getPassword())){
				LOG.error("EXCEPTION : \"Please enter a valid email and password \" raised in login() of AuthenticationServiceImpl class" );
				throw new NotFoundException("Please enter a valid email and password");
			} else {
				final Object param1[][] = {{"userId", user}};	
				UserRole userRole = securityRelationalRepository.find("UserRole.findByUserId", new QueryParameters(param1), UserRole.class);
				final Object param2[][] = {{"roleId", userRole.getRoleId()}};
				Role role = securityRelationalRepository.find("Role.findById", new QueryParameters(param2), Role.class);
				user.setRoleName(role.getRoleName());
				UserData userData = new UserData();
				BeanUtils.copyProperties(userData, user);
				userData.setLocation("");
				userData.setDob(user.getDob() ==null ? "" :user.getDob().toString());
				LOG.debug("ENDED : login() of AuthenticationServiceImpl class");
				return userData;
			}
		} catch (PersistenceException pe) {
			LOG.error(pe);
			Throwable t= pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}	
	}
	
	@Override
	@Transactional
	public User forgetPassword(PasswordUpdate forgetPassword) throws ServiceException, InvalidDataException, NotFoundException, InvalidUserException {
		try {
			LOG.debug("STARTED : forgetPassword() of AuthenticationServiceImpl class");
			if(forgetPassword.getEmail() == null){
				LOG.error("EXCEPTION : \"email is required \" raised in forgetPassword() of AuthenticationServiceImpl class" );
				throw new InvalidDataException("email is required");
			} else{
				final Object param[][] = {{"email", forgetPassword.getEmail()}};
				User user = securityRelationalRepository.find("User.findByEmail", new QueryParameters(param), User.class);
				if(user == null){
					LOG.error("EXCEPTION : \"please enter valid email id \" raised in forgetPassword() of AuthenticationServiceImpl class" );
					throw new NotFoundException("please enter valid email id");	
				} else {
					user.setToken(UUID.randomUUID().toString());
					Calendar cal = Calendar.getInstance();
					user.setTokenCreatedTime(cal.getTime());
					LOG.debug("ENDED : forgetPassword() of AuthenticationServiceImpl class");
					return securityRelationalRepository.update(user);		
				}
			}
		} catch (PersistenceException pe) {
			LOG.error(pe);
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
		
	}
	
	@Override
	public User verifyToken(String token) throws ServiceException, InvalidDataException, NotFoundException {
		try {
			LOG.debug("STARTED : verifyToken() of AuthenticationServiceImpl class");
			final Object param[][] = {{"token", token}};
			User user = securityRelationalRepository.find("User.findByToken", new QueryParameters(param), User.class);	
			if(user == null){
				LOG.error("EXCEPTION : \"Invalid password link, please click on latest link or generate new password link \" raised in verifyToken() of AuthenticationServiceImpl class" );
				throw new NotFoundException("Invalid password link, please click on latest link or generate new password link");
			} else if((new Date().getTime()-user.getTokenCreatedTime().getTime())/(60*60*1000.0)%24 > 1){
				LOG.error("EXCEPTION : \"This link has expired, please generate new link \" raised in verifyToken() of AuthenticationServiceImpl class" );
				throw new InvalidDataException("This link has expired, please generate new link");
			} else {
				LOG.debug("ENDED : verifyToken() of AuthenticationServiceImpl class");
				return user;
			}
		} catch (PersistenceException pe) {
			LOG.error(pe);
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
		
	}
	
	@Override
	@Transactional
	public UserData updatePassword(PasswordUpdate updateData) throws NotFoundException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException {
		try {
			LOG.debug("STARTED : updatePassword() of AuthenticationServiceImpl class");
			final Object params[][] = {{"token", updateData.getToken()}};
			User user = securityRelationalRepository.find("User.findByToken", new QueryParameters(params), User.class);
			if(user == null){
				LOG.error("EXCEPTION : \"Invalid password link, please click latest link or generate new password link \" raised in updatePassword() of AuthenticationServiceImpl class" );
				throw new NotFoundException("Invalid password link, please click latest link or generate new password link");
			} else if((new Date().getTime()-user.getTokenCreatedTime().getTime())/(60*60*1000.0)%24 > 1){
				LOG.error("EXCEPTION : \"this link has expired, please generate new link \" raised in updatePassword() of AuthenticationServiceImpl class" );
				throw new InvalidDataException("this link has expired, please generate new link");
			} else if(!updateData.getPassword().equals(updateData.getConfirmPassword())){
				LOG.error("EXCEPTION : \"please enter valid new password and confirm password, both should match \" raised in updatePassword() of AuthenticationServiceImpl class" );
				throw new InvalidDataException("please enter valid new password and confirm password, both should match");
			} else {			
				user.setPassword(bCryptPasswordEncoder.encode(updateData.getPassword()));
				user.setToken(null);
				user.setTokenCreatedTime(null);
				User user1 = securityRelationalRepository.update(user);
				UserData data = new UserData();
				BeanUtils.copyProperties(data, user1);
				LOG.debug("ENDED : updatePassword() of AuthenticationServiceImpl class");
				return data;
			}
		} catch (PersistenceException pe) {
			LOG.error(pe);
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	public DashboardResponse deshboard() throws ServiceException {
		try {
			LOG.debug("STARTED : deshboard() of AuthenticationServiceImpl class");
			DashboardResponse response = new DashboardResponse();
			Long chargePointCount = securityRelationalRepository.find("ChargePoint.count",new QueryParameters(null), Long.class);
			Long unknownChargePointCount = securityRelationalRepository.find("UnknownChargePoint.count", new QueryParameters(null), Long.class);
			Long activeChargePointCount = securityRelationalRepository.find("ChargePoint.Active", new QueryParameters(null), Long.class);
			response.setChargePointCount(chargePointCount);
			response.setActiveChargePointCount(activeChargePointCount);
			response.setUnknownChargePointCount(unknownChargePointCount);	
			LOG.debug("ENDED : deshboard() of AuthenticationServiceImpl class");
			return response;
		} catch (PersistenceException pe) {
			LOG.error(pe);
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	@Transactional
	public UserLogin getUserLogin(UserLogin login) throws NotFoundException, ServiceException, NoSuchAlgorithmException {
		try {
			LOG.debug("STARTED : getUserLogin() of AuthenticationServiceImpl class");
			Object param[][] = {{"userName", login.getUserName()}};
			UserLogin user = securityRelationalRepository.find("UserLogin.findByuserName", new QueryParameters(param), UserLogin.class);
			if(user == null) {		
				LOG.error("EXCEPTION : \"Please enter valid username and password \"raised in getUserLogin() of AuthenticationServiceImpl class" );
				throw new NotFoundException("Please enter valid username and password");
			} else{
				String md5 = null;
				MessageDigest md = MessageDigest.getInstance("MD5");
				md.update(login.getPassword().getBytes());
				byte[] digest = md.digest();
				md5 = new BigInteger(1, digest).toString(16);
				if(md5.equals(user.getPassword())) {
					System.out.println(12);
					LOG.debug("ENDED : getUserLogin() of AuthenticationServiceImpl class");
					return user;
				}else {
					LOG.error("EXCEPTION : \"Please enter valid username and password \"raised in getUserLogin() of AuthenticationServiceImpl class" );
					throw new NotFoundException("Please enter valid username and password");
				}
			}
		} catch (PersistenceException e) {
			LOG.error(e);
			throw new ServiceException(e.getCause() == null ? e : e.getCause());
		}
		
	}
}
