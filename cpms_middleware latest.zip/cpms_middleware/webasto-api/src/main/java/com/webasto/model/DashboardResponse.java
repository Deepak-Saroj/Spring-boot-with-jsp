package com.webasto.model;

public class DashboardResponse {

	private Long chargePointCount;
	private Long activeChargePointCount;
	private Long unknownChargePointCount;

	public Long getChargePointCount() {
		return chargePointCount;
	}

	public void setChargePointCount(Long chargePointCount) {
		this.chargePointCount = chargePointCount;
	}

	public Long getActiveChargePointCount() {
		return activeChargePointCount;
	}

	public void setActiveChargePointCount(Long activeChargePointCount) {
		this.activeChargePointCount = activeChargePointCount;
	}

	public Long getUnknownChargePointCount() {
		return unknownChargePointCount;
	}

	public void setUnknownChargePointCount(Long unknownChargePointCount) {
		this.unknownChargePointCount = unknownChargePointCount;
	}
	
}
