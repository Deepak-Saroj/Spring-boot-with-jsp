package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.Address;
import com.webasto.model.BulkActiveDeactive;
import com.webasto.model.ChargePoint;
import com.webasto.model.ChargePointData;
import com.webasto.model.ChargingProfile;
import com.webasto.model.Connector;
import com.webasto.model.Response;
import com.webasto.model.UnknownChargePoint;

@Service
public class ChargePointServiceImpl implements ChargePointService {
	
	
	private static final Logger LOG = LogManager.getLogger(ChargePointServiceImpl.class);

	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;
	
/*	@PersistenceContext
	private EntityManager manager;
	
	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;
	*/
	
	@Override
	@Transactional
	public ChargePointData addChargingPoint(ChargePoint chargePointData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException {
		try {
			LOG.debug("STARTED : addChargingPoint() of ChargePointServiceImpl class: ");
			final Object param[][] = {{"chargePointId", chargePointData.getChargePointId()}};
			ChargePoint oldChargePoint = securityRelationalRepository.find("ChargePoint.findByChargePointId", new QueryParameters(param), ChargePoint.class);
			if(oldChargePoint != null){
				LOG.error("EXCEPTION : \"Chargepoint is already exists\" raised in addChargingPoint() of ChargePointServiceImpl class" );
				throw new UniqueConstraintException("Chargepoint is already exists");
			} else {
				//chargePointData.setCreatedTime(Calendar.getInstance().getTime());
				Address address = chargePointData.getAddress();
				System.out.println("address "+ address);
				if(address.getHouseNumber() != "" || address.getStreet() != "" || address.getZipCode() != "" || address.getCity() != "" || address.getCountry() != "" || address.getLocationLatitude() !=null || address.getLocationLongitude()!=null){
					if(address.getLocationLatitude() !=null && address.getLocationLatitude() > 999.99 || address.getLocationLongitude()!=null && address.getLocationLongitude() > 999.99){
						throw new InvalidDataException("Latitude and longitude should not greater then 999.99");
					}
					chargePointData.setAddress(address);
				} else {
					chargePointData.setAddress(null);
				}
				chargePointData.setActive((short)1);
				ChargePoint newChargePoint = securityRelationalRepository.create(chargePointData);
				ChargePointData chargePoint = new ChargePointData();
				BeanUtils.copyProperties(chargePoint, newChargePoint);
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				chargePoint.setCreatedTime(dateFormat.format(newChargePoint.getCreatedTime()));
				chargePoint.setModifiedTime(dateFormat.format(newChargePoint.getModifiedTime()));
				LOG.debug("ENDED : addChargingPoint() of ChargePointServiceImpl class");
				return chargePoint;
			}
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of addChargingPoint() of ChargePointServiceImpl class" );
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe.getCause() : t.getCause());
		}
	}
	
	@Override
	public List<ChargePointData> getChargePointList() throws IllegalAccessException, InvocationTargetException, ServiceException {
		try {
			LOG.debug("STARTED : getChargePointList() of ChargePointServiceImpl class: ");
			List<ChargePoint> chargePointList = securityRelationalRepository.list("ChargePoint.list", new QueryParameters(null), ChargePoint.class);
			List<ChargePointData> chargePointDataList = new ArrayList<ChargePointData>();
			for(ChargePoint chargePoint : chargePointList){
				ChargePointData chargePointData = new ChargePointData();
				BeanUtils.copyProperties(chargePointData, chargePoint);
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				chargePointData.setCreatedTime(dateFormat.format(chargePoint.getCreatedTime()));
				chargePointData.setModifiedTime(dateFormat.format(chargePoint.getModifiedTime()));
				chargePointDataList.add(chargePointData);
			}
			LOG.debug("ENDED : getChargePointList() of ChargePointServiceImpl class");
			return chargePointDataList;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of getChargePointList() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	public ChargePointData getChargePoint(int id) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException, ParseException {
		try {
			LOG.debug("STARTED : getChargePoint() of ChargePointServiceImpl class: ");
			//final Object param[][] = {{"chargePointId", chargePointId}};
			ChargePoint chargePoint = securityRelationalRepository.find(id, ChargePoint.class);
			//ChargePoint chargePoint = securityRelationalRepository.find("ChargePoint.findByChargePointId", new QueryParameters(param), ChargePoint.class);
			if(chargePoint == null){
				LOG.error("EXCEPTION : \"Please enter valid charge point id\" raised in getChargePoint() of ChargePointServiceImpl class" );
				throw new NotFoundException("Please enter valid charge point id");
			} else{
				LOG.debug("ENDED : getChargePoint() of ChargePointServiceImpl class");
				/*SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
				String format = dateFormat.format(chargePoint.getCreatedTime());*/
				ChargePointData chargePointData = new ChargePointData();
				BeanUtils.copyProperties(chargePointData, chargePoint);
				/*if(chargePointData.getAddress() == null){
					Address address = new Address();
					address.setCity("");
					address.setCountry("");
					address.setHouseNumber("");
					address.setStreet("");
					address.setZipCode("");
					address.setStreet("");
					chargePointData.setAddress(address);
				}*/
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				chargePointData.setCreatedTime(dateFormat.format(chargePoint.getCreatedTime()));
				chargePointData.setModifiedTime(dateFormat.format(chargePoint.getModifiedTime()));
				//System.out.println(format);
				return chargePointData;
			}
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of getChargePoint() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe.getCause() : t.getCause());
		}
	}
	
	@Override
	@Transactional
	public ChargePointData updateChargePoint(ChargePoint chargePoint) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException, InvalidDataException {
		try {
			LOG.debug("STARTED : updateChargePoint() of ChargePointServiceImpl class: ");
			final Object param[][] = {{"chargePointId", chargePoint.getChargePointId()}};
			ChargePoint oldChargePoint = securityRelationalRepository.find("ChargePoint.findByChargePointId", new QueryParameters(param), ChargePoint.class);
			if(oldChargePoint == null){
				LOG.error("EXCEPTION : \"Chargepoint does not exists\" raised in updateChargePoint() of ChargePointServiceImpl class" );
				throw new NotFoundException("Chargepoint does not exists");
			} else {
				oldChargePoint.setDescription(chargePoint.getDescription());
				if(oldChargePoint.getAddress() == null){
					Address address = chargePoint.getAddress();
					if(address.getHouseNumber() != "" || address.getStreet() != "" || address.getZipCode() != "" || address.getCity() != "" || address.getCountry() != "" || address.getLocationLatitude() !=null || address.getLocationLongitude()!=null){
						if(address.getLocationLatitude() !=null && address.getLocationLatitude() > 999.99 || address.getLocationLongitude()!=null && address.getLocationLongitude() > 999.99){
							throw new InvalidDataException("Latitude and longitude should not greater then 999.99");
						}
						oldChargePoint.setAddress(address);
					} 
				} else {
					Address newAddress = chargePoint.getAddress();
					newAddress.setId(oldChargePoint.getAddress().getId());
					newAddress.setCreatedTime(oldChargePoint.getAddress().getCreatedTime());
					oldChargePoint.setAddress(newAddress);
				}
				LOG.debug("ENDED : updateChargePoint() of ChargePointServiceImpl class");
				
				ChargePoint updatedChargePoint = securityRelationalRepository.update(oldChargePoint);
				ChargePointData updatedChargePointData = new ChargePointData();
				BeanUtils.copyProperties(updatedChargePointData, updatedChargePoint);
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				updatedChargePointData.setCreatedTime(dateFormat.format(updatedChargePoint.getCreatedTime()));
				updatedChargePointData.setModifiedTime(dateFormat.format(updatedChargePoint.getModifiedTime()));
				return updatedChargePointData;
			}
		} catch (PersistenceException pe){
			LOG.error("EXCEPTION : Catch block executed of updateChargePoint() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
		
	}
	
	@Override
	@Transactional
	public List<ChargePointData> activateOrDeactivateChargePoint(ChargePointData chargePoint) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException {
		try {
			ChargePoint oldChargePoint = securityRelationalRepository.find(chargePoint.getId(), ChargePoint.class);
			if(oldChargePoint == null){
				throw new NotFoundException("Chargepoint does not exists");
			} else {
				oldChargePoint.setActive(chargePoint.getActive());
				ChargePoint newChargePoint = securityRelationalRepository.update(oldChargePoint);
				ChargePointData updatedChargePoint = new ChargePointData();
				BeanUtils.copyProperties(updatedChargePoint, newChargePoint);
				return getChargePointList();
				//return updatedChargePoint;
			}
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	@Transactional
	public List<ChargePointData> activateOrDeactivateBulkChargePoint(BulkActiveDeactive bulkActiveDeactiveList) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException {
		try {
			List<ChargePointData> updatedChargePointList = new ArrayList<>();
			List<Integer> idList = bulkActiveDeactiveList.getId();
			for(Integer id : idList){
				ChargePoint oldChargePoint = securityRelationalRepository.find(id, ChargePoint.class);
				if(oldChargePoint != null){
					if(oldChargePoint.getActive() == bulkActiveDeactiveList.getActive()){
						System.out.println(1);
					} else {
						System.out.println(2);
						oldChargePoint.setActive(bulkActiveDeactiveList.getActive());
						ChargePoint newChargePoint = securityRelationalRepository.update(oldChargePoint);
						ChargePointData updatedChargePoint = new ChargePointData();
						BeanUtils.copyProperties(updatedChargePoint, newChargePoint);
						updatedChargePointList.add(updatedChargePoint);
					}		
				} 
			}
			return updatedChargePointList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	@Override
	@Transactional
	public Response deleteChargePoint(int id) throws NotFoundException, ServiceException {
		try {
			LOG.debug("STARTED : deleteChargePoint() of ChargePointServiceImpl class: ");

			//final Object param[][] = {{"chargePointId", chargePointId}};
			//ChargePoint chargePoint = securityRelationalRepository.find("ChargePoint.findByChargePointId", new QueryParameters(param), ChargePoint.class);
			ChargePoint chargePoint = securityRelationalRepository.find(id, ChargePoint.class);
			if(chargePoint == null){
				LOG.error("EXCEPTION : \"Charge box is not exist\" raised in deleteChargePoint() of ChargePointServiceImpl class" );
				throw new NotFoundException("charge point does not exist");
			} else {
				securityRelationalRepository.remove(chargePoint);
				Response response = new Response();
				response.setMessage("success");
				LOG.debug("ENDED : deleteChargePoint() of ChargePointServiceImpl class");
				return response;
			}
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of deleteChargePoint() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	@Transactional
	public Response deleteChargePoints(List<Integer> idList) throws NotFoundException, ServiceException {
		try {
			LOG.debug("STARTED : deleteChargePoint() of ChargePointServiceImpl class: ");
			final Object param[][] = {{"idList", idList}};
			Response response = new Response();
			securityRelationalRepository.remove("ChargePoint.DeleteList", new QueryParameters(param));
			response.setMessage("Charge points deleted successfully");
			return response;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of deleteChargePoint() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	public List<String> getConnector(List<String> cpList, int conId) throws ServiceException {
		try {
			List<Object[]> con = securityRelationalRepository.listConnector(cpList, conId);
			System.out.println(con.size());
			List<String> unCpList = new ArrayList<>();
			for(Object[] obj : con){
				cpList.remove(obj[0]);
			}
			return cpList;
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException();
		}
		
	}
	
	
	@Override
	public List<ChargingProfile> getChargingProfileList() throws ServiceException {
		try {
			LOG.debug("STARTED : getChargingProfileList() of ChargePointServiceImpl class");
			List<ChargingProfile> profileList = securityRelationalRepository.list("ChargingProfile.list", new QueryParameters(null), ChargingProfile.class);
			LOG.debug("ENDED : getChargingProfileList() of ChargePointServiceImpl class");
			return profileList;
		} catch (PersistenceException pe) {
			LOG.error("EXCEPTION : Catch block executed of getChargingProfileList() of ChargePointServiceImpl class");
			Throwable t = pe.getCause();
			throw new ServiceException(t == null ? pe : t.getCause());
		}
	}
	
	@Override
	@Transactional
	public ChargingProfile addChargingProfile(ChargingProfile chargingProfile) throws ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	
	@Override
	public ChargingProfile getChargingProfile(int chargingProfileId) throws NotFoundException, ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	
	@Override
	@Transactional
	public ChargingProfile updateChargingProfile(ChargingProfile profile) throws NotFoundException, ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	
	@Override
	@Transactional
	public Response deleteChargingProfile(int profileId) throws NotFoundException, ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
	
	@Override
	public void chargePointStatus() throws ServiceException {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	
	
	@Override
	public List<UnknownChargePoint> getUnknownChargePointList() throws ServiceException {
		try {
			List<UnknownChargePoint> unknownChargePointList = securityRelationalRepository.list("UnknownChargePoint.list", new QueryParameters(null),  UnknownChargePoint.class);
			return unknownChargePointList;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
}
