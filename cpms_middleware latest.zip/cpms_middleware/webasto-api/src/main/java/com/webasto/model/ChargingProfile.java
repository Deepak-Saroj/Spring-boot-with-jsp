package com.webasto.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

//@Entity
@Table(name = "charging_profile")
//@NamedQueries(value = {@NamedQuery(name = "ChargingProfile.list", query = "SELECT c FROM ChargingProfile c")})
public class ChargingProfile {

	@Id
	@Column(name = "charging_profile_pk")
	private int chargingProfilePk;
	
	@Column(name = "stack_level")
	private Integer stackLevel;
	
	@Column(name = "charging_profile_purpose")
	private String chargingProfilePurpose;
	
	@Column(name = "charging_profile_kind")
	private String chargingProfileKind;
	
	@Column(name = "recurrency_kind")
	private String recurrencyKind;
	
	@Column(name = "valid_from")
	private Date validFrom;
	
	@Column(name = "valid_to")
	private Date validTo;
	
	@Column(name = "duration_in_seconds")
	private Integer durationInSeconds;
	
	@Column(name = "start_schedule")
	private Date startSchedule;
	
	@Column(name = "charging_rate_unit")
	private String chargingRateUnit;
	
	@Column(name = "min_charging_rate")
	private Double minChargingRate;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "note")
	private String note;
	
}
