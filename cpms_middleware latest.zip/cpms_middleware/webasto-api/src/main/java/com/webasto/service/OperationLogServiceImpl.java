package com.webasto.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webasto.commons.sql.data.QueryParameters;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.dao.SecurityRelationalRepository;
import com.webasto.model.CSOperation;

@Service
public class OperationLogServiceImpl implements OperationLogService{

	@Autowired
	private SecurityRelationalRepository securityRelationalRepository;
	
	@Override
	public List<CSOperation> getOperations(String date) throws ServiceException {
		try {
			final Object param[][] = {{"date", date}};
			List<Object> objList = securityRelationalRepository.list(date);
			List<Object[]> objList1 = securityRelationalRepository.list(date);
			List<CSOperation> ope = new ArrayList<CSOperation>();
			for(Object[] l : objList1){
			//List l = (List)obj;
				CSOperation operation = new CSOperation();
				operation.setName((String)l[0]);
				operation.setCreatedTime((Date)l[1]);
				ope.add(operation);
			//System.out.println((String)(l[0]));
			//System.out.println(l[1]);
	
			}
			System.out.println(objList);
			//List<CSOperation> operationList = securityRelationalRepository.list("CSOperation.listBasedOnDate", new QueryParameters(param), CSOperation.class);
			//System.out.println(operationList);
			return ope;
		} catch (PersistenceException pe) {
			throw new ServiceException(pe.getCause() == null ? pe : pe.getCause());
		}
	}
	
	public void createOperation() {
		// TODO Auto-generated method stub
		
	}
	public void createOperationLog() {
		// TODO Auto-generated method stub
		
	}
}
