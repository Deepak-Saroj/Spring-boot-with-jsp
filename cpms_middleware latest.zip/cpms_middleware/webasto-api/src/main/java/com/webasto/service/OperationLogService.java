package com.webasto.service;

import java.util.List;

import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.CSOperation;

public interface OperationLogService {

	public List<CSOperation> getOperations(String date)throws ServiceException;
	public void createOperation();
	public void createOperationLog();
}
