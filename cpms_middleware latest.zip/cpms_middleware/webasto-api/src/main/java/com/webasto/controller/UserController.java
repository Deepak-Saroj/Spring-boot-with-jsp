package com.webasto.controller;


import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.BulkActiveDeactive;
import com.webasto.model.Response;
import com.webasto.model.ResponseList;
import com.webasto.model.User;
import com.webasto.model.UserData;
import com.webasto.model.UserLogin;
import com.webasto.service.UserService;

@RestController
@CrossOrigin
@RequestMapping("/user")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserController {

	private static final Logger LOG = LogManager.getLogger(UserController.class);

	@Autowired
	private UserService userService;
	
	/** This method is used to create a new user  
	 * @author Manoj_Gupta
	 * @param  User instance
	 * @return UserData 
	 * @throws UniqueConstraintException 'if user already exist'
	 * @throws ServiceException 'if any internal server problem'
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ResponseEntity<Response> registration(@RequestBody User user) throws ServiceException, UniqueConstraintException, PersistenceException, AddressException, MessagingException, ParseException{
		try {
			LOG.debug("STARTED : registration() of UserController class");
			System.out.println(1);
			Response response = userService.createUser(user);
			LOG.debug("ENDED : registration() of UserControler class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used to get the user list  
	 * @author Manoj_Gupta
	 * @return List<UserData> 
	 * @throws ServiceException 'If any internal server problem'
	 */
	@RequestMapping( value= "/search", method = RequestMethod.GET)
	public ResponseEntity<ResponseList> getUsersList() throws ServiceException{
		try {
			LOG.debug("STARTED : getUsers() of UserController class");
			ResponseList response = new ResponseList();
			List usersList = userService.getUserList();
			response.setMessage("Users list");
			response.setData(usersList);
			LOG.debug("ENDED : getUsers() of UserController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	

	/** This method is used to get the user data based on email id  
	 * @author Manoj_Gupta
	 * @param  emailId 
	 * @return UserData 
	 * @throws NotFoundException 'if user is not exist'
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/search/{userId}", method = RequestMethod.GET)
	public ResponseEntity<UserData> showUser(@PathVariable int userId) throws ServiceException, NotFoundException, IllegalAccessException, InvocationTargetException{
		try {
			LOG.debug("STARTED : showUser() of UserController class");
			UserData userData = userService.getUser(userId);
			LOG.debug("ENDED : showUser() of UserController class");
			return ResponseEntity.ok(userData);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	

	/** This method is used to delete a user  
	 * @author Manoj_Gupta
	 * @param  UserData instance
	 * @return UserData 
	 * @throws NotFoundException 'if user is not exist'
	 * @throws ServiceException 'if any internal server problem'
	 */
	@RequestMapping(value = "/delete/{userId}", method = RequestMethod.DELETE)
	public ResponseEntity<Response> deleteUser(@PathVariable int userId) throws NotFoundException, ServiceException{
		try {
			LOG.debug("STARTED : deleteUser() of UserController class");
			Response response = userService.deleteUser(userId);
			LOG.debug("ENDED : deleteUser() of UserController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/** This method is used to get user list based on pagination  
	 * @author Manoj_Gupta
	 * @param  pageNumbr, PageSize
	 * @return List<UserData> 
	 * @throws ServiceException 'if any internal server problem'
	 */
	//@RequestMapping(value = "/search", method = RequestMethod.GET)
	public void userList(@RequestParam int pageNumber, @RequestParam int pageSize) throws ServiceException{
		try {
			LOG.debug("STARTED : userList() of UserController class");
			System.out.println(1);
			userService.getUserList(pageNumber, pageSize);
			LOG.debug("ENDED : userList() of UserController class");
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/bulkactive", method = RequestMethod.PUT)
	public ResponseEntity<ResponseList> activeOrDeactiveUser(@RequestBody BulkActiveDeactive activateDeactivate) throws ServiceException{
		try {
			LOG.debug("STARTED : activeOrDeactiveUser() of UserController class");
			ResponseList response = new ResponseList();
			List updatedUserList = userService.activateOrDeactivateUser(activateDeactivate);
			response.setMessage("Updated user list");
			response.setData(updatedUserList);
			LOG.debug("ENDED : activeOrDeactiveUser() of UserController class");
			return ResponseEntity.ok(response);
			
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	
}
