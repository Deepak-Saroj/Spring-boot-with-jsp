package com.webasto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.Transaction;
import com.webasto.service.TransactionService;

@RestController
@CrossOrigin
@RequestMapping(value = "/transaction")
public class TransactionController {
	
	@Autowired
	private TransactionService transactionService;
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ResponseEntity<List<Transaction>> getTransactionList() throws ServiceException{
		try {
			List<Transaction> list = transactionService.getTransactionList();
			return ResponseEntity.ok(list);
		} catch (ServiceException se) {
			throw new ServiceException("internal server error");
		}
	}

}
