package com.webasto.model;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.core.io.InputStreamResource;

//import com.mysql.fabric.xmlrpc.base.Data;

public class Download {
	static Download download=new Download();

	public static Map<String,XSSFWorkbook> data=new HashMap<String,XSSFWorkbook>();

	public static XSSFWorkbook getData(String key) throws IOException {
		XSSFWorkbook fdfd= data.get(key);
	//	System.out.println("get hashcode : "+fdfd.contentLength());
		return fdfd;
	}

	public void setData(Map<String, XSSFWorkbook> data) {
		System.out.println("setting hashcode : "+data.hashCode());
		this.data = data;
	}
	
	public void setdata(String key, XSSFWorkbook data) {
		System.out.println("setting hashcode : "+data.hashCode());
		 this.data.put(key, data);
	}
	
	public static Download getDownload(){
		if(download!=null) {
			return download;
		}
		return null;
	}

}
