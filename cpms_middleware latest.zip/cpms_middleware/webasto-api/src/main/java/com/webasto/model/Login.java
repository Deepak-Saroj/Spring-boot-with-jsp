package com.webasto.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

public class Login {

	@Pattern(regexp = "^$|\\w+([-+.]\\w+)*@(\\w+\\.com)", message = "Please enter a valid email format")
	@NotNull
	private String email;
	
	//@Pattern(regexp ="^.{6,14}$", message = "Password length should lies between 6 to 14 characters")
	//@Size(min = 6, max = 14, message = "length")
	private String password;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
