package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.security.NoSuchAlgorithmException;

import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.InvalidUserException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.DashboardResponse;
import com.webasto.model.Login;
import com.webasto.model.PasswordUpdate;
import com.webasto.model.User;
import com.webasto.model.UserData;
import com.webasto.model.UserLogin;

public interface AuthenticationService {

	public UserData login(Login login) throws NotFoundException, ServiceException, IllegalAccessException, InvocationTargetException;
	public User forgetPassword(PasswordUpdate forgetPassword) throws ServiceException, InvalidDataException, NotFoundException, InvalidUserException;
	public User verifyToken(String token) throws ServiceException, InvalidDataException, NotFoundException;
	public UserData updatePassword(PasswordUpdate updateData) throws NotFoundException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public DashboardResponse deshboard()throws ServiceException;
	public UserLogin getUserLogin(UserLogin login) throws NotFoundException, ServiceException, NoSuchAlgorithmException;
	
}
