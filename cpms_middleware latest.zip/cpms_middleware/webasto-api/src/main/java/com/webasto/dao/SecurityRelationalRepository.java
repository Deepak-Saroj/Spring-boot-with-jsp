package com.webasto.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.webasto.commons.sql.data.AbstractRelationalRepository;

@Repository
public class SecurityRelationalRepository extends com.webasto.commons.sql.data.AbstractRelationalRepository {
	
	@PersistenceContext
	public void setEntityManager(final EntityManager entityManager) {
        this.entityManager = entityManager;
    }
	
}
	