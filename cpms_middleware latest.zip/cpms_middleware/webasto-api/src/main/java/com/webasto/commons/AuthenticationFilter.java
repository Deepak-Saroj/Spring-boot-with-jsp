package com.webasto.commons;

import java.io.IOException;
import java.security.SignatureException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.webasto.service.AuthenticationService;




@Component
@WebFilter(urlPatterns = "/*")
public class AuthenticationFilter implements Filter {

	@Value("${user.time_zone}")
	private String timeZone;

	private static final Logger LOG = Logger.getLogger(AuthenticationFilter.class);
	
	private static List<String> AUTH_FREE_PATHS = new ArrayList<String>();
	static {
		AUTH_FREE_PATHS.add("/login");
	}

	public void init(FilterConfig filterConfig) throws ServletException {

	}
	
	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		try {
			System.out.println("AuthenticationFilter.doFilter()");
			final SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm");
			dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
			ThreadLocalContext.set(ThreadLocalContext.DATE_FORMAT, dateFormat);
			chain.doFilter(req, res);
			ThreadLocalContext.destroy();
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}
	}

}
