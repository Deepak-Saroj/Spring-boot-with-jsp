package com.webasto.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.exception.BadRequestException;
import com.webasto.model.Address;
import com.webasto.model.BulkChargeResponse;
import com.webasto.model.ChargePoint;
import com.webasto.model.Download;
import com.webasto.service.ChargePointService;

@CrossOrigin
@RestController
@RequestMapping(value = "/chargepoints")
public class BulkChargePointController {
	
	private static final Logger LOG = LogManager.getLogger(BulkChargePointController.class);

	@Autowired
	private ChargePointService chargePointService;
	
	@Value("${cpms.url}")
	private String url;
		
	@PostMapping(value="/bulkupload")
	public ResponseEntity<BulkChargeResponse> uploadBulkChargePoints(@RequestPart(value = "file") MultipartFile bulkChargePointFile,HttpServletResponse response) throws IOException, BadRequestException, InvalidDataException {
		System.out.println(1);
		System.out.println(bulkChargePointFile.getOriginalFilename());
		String fileName=bulkChargePointFile.getOriginalFilename();
		String[] extension=fileName.split("\\.");
	
		int length=extension.length;
     if(length >1 && extension[1].equals("xlsx")) {
        XSSFWorkbook workbook=null;
		try {
			workbook = new XSSFWorkbook(bulkChargePointFile.getInputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 CellStyle style = workbook.createCellStyle();  
         // Setting Background color  
         style.setFillBackgroundColor(IndexedColors.GREEN.getIndex()); 
         style.setFillPattern(FillPatternType.THIN_FORWARD_DIAG);
         CellStyle redColor = workbook.createCellStyle();  
         // Setting Background color  
         redColor.setFillBackgroundColor(IndexedColors.RED.getIndex());  
        //Get first/desired sheet from the workbook
         redColor.setFillPattern(FillPatternType.THIN_FORWARD_DIAG);
        XSSFSheet sheet = workbook.getSheetAt(0);
        ByteArrayOutputStream out = null;
        ByteArrayInputStream bis =null;
        //Iterate through each rows one by one
        Iterator<Row> rowIterator = sheet.iterator();
	    while (rowIterator.hasNext())
        {
            Row row = rowIterator.next();
       
       if(row.getRowNum()!=0) {
    	   Cell cell=     row.getCell(0);
    	   if(cell !=null){
    		   ChargePoint chargePoint=new ChargePoint();
    		   chargePoint.setActive((short)1);
    		   chargePoint.setChargePointId(cell.getStringCellValue());
    		  Cell description= row.getCell(1);
    		  System.out.println(cell);
    		  chargePoint.setDescription((description!=null)?description.getStringCellValue():null);
    		  Cell houseNo= row.getCell(2);
    		  Address address=new Address();
    		  
    		  if(houseNo!=null) {
    			  System.out.println("house");
    			  System.out.println("type "+houseNo.getCellType());
    			  address.setHouseNumber(houseNo.getStringCellValue());
    		  }
    		  Cell street= row.getCell(3);
    		  if(street!=null) {
    			  System.out.println("house");
    			  address.setStreet(street.getStringCellValue());
    		  }
    		  Cell zipcode= row.getCell(4);
				 if(zipcode!=null) {
					 System.out.println("house");
					 Long zipCode = (long) zipcode.getNumericCellValue();
					 address.setZipCode(String.valueOf(zipCode)); 			  
				    		  }
				 Cell city= row.getCell(5);  		  

				 if(city!=null) {
					  System.out.println("house");
					 address.setCity(city.getStringCellValue());
				 }
 
				 Cell country= row.getCell(6);
				 if(country!=null) {
					  System.out.println("house");																	
					address.setCountry(country.getStringCellValue());  
				 }
				 chargePoint.setAddress(address);
				 try {
					  System.out.println("house");
					chargePointService.addChargingPoint(chargePoint);
					 Cell commentCell=row.createCell(7);
					commentCell.setCellValue("Charge point is added sucessfully");
					commentCell.setCellStyle(style);
				} catch (UniqueConstraintException e) {
					System.out.println("unique");
					LOG.error(e);
					 Cell commentCell=row.createCell(7);
					 System.out.println("charge is already exists.");
		        	   commentCell.setCellValue("Charge point id is already exists.");
		        	   commentCell.setCellStyle(redColor);
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					
				}
    	    	System.out.println("cp id :"+cell.getStringCellValue() +" " +description);
           }else {
        	   Cell commentCell=row.createCell(7);
        	   commentCell.setCellValue("Charge point id is empty");
        	   commentCell.setCellStyle(redColor);
           	System.out.println("CP id should not be null ");
           }
    	  
		
     }else {
    	 System.out.println("1st row reading");
    	 Font headerFont = workbook.createFont();
			headerFont.setBold(true);
	        headerFont.setFontHeightInPoints((short) 12);
    	 Cell commentCell=row.createCell(7);
    	 commentCell.setCellValue("Comments");
    	 CellStyle headerCellStyle = workbook.createCellStyle();
    	 commentCell.setCellStyle(headerCellStyle);
     }
       
    
    
		
    }
	    out = new ByteArrayOutputStream();
	 			workbook.write(out);
	   
			
			System.out.println("lenght of array : "+out.toByteArray().length);
			 bis=new ByteArrayInputStream(out.toByteArray());
			
           
        	FileOutputStream fdfd=new FileOutputStream("BulkChargePonts1.xlsx");
        	workbook.write(fdfd);
			//workbook.close();
	   Download data= Download.getDownload();
	   
	   data.setdata("data", workbook);
	  bis.close();
	  
	   
    
     return ResponseEntity
                  .ok()
                  .body(new BulkChargeResponse("Sucess","/chargepoints/download/buldChargePoints"));
    
	}else {
		System.out.println("not excel sheet");
		throw new BadRequestException("Please attach the excel sheet only.");
	}
	}
	
	@GetMapping(value="/download/buldChargePoints")
	public ResponseEntity<InputStreamResource> downloadFile(HttpServletRequest request) throws IOException{
		
		Download data= Download.getDownload();
		  HttpHeaders headers = new HttpHeaders();
	        headers.add("Content-Disposition", "attachment; filename=BulkChargePointResult.xlsx");
	        headers.add("Content-Type","text/html");
	        
	        ByteArrayOutputStream   out = new ByteArrayOutputStream();
	        ByteArrayInputStream bis;
	        data.getData("data").write(out);;
	        bis=new ByteArrayInputStream(out.toByteArray());
	        InputStreamResource inputStreamResource =new InputStreamResource(bis);
	  	  bis.close();
		if(inputStreamResource !=null) {
			return ResponseEntity
	                  .ok()
	                  .headers(headers)
	                  .body(inputStreamResource);
		
		}
		return ResponseEntity
                .ok().body(null);
		
		 
	    }
	
	@RequestMapping(value = "/template/download", method = RequestMethod.GET)
	public ResponseEntity<InputStreamResource> downloadTemplate() throws ServiceException{
		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("Bulk Import");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
	        headerFont.setFontHeightInPoints((short) 12);
	        //headerFont.setColor(IndexedColors.RED.getIndex());
	        CellStyle headerCellStyle = workbook.createCellStyle();
	        headerCellStyle.setFont(headerFont);
			Row headerRow = sheet.createRow(0);
			Cell chargePoint = headerRow.createCell(0);
			chargePoint.setCellValue("Charge Point ID *");	
			chargePoint.setCellStyle(headerCellStyle);
			Cell description = headerRow.createCell(1);
			description.setCellValue("Description");
			description.setCellStyle(headerCellStyle);
			Cell houseNO = headerRow.createCell(2);
			houseNO.setCellValue("House No");
			houseNO.setCellStyle(headerCellStyle);
			Cell street = headerRow.createCell(3);
			street.setCellValue("Street");
			street.setCellStyle(headerCellStyle);
			Cell zipCode = headerRow.createCell(4);
			zipCode.setCellValue("Zip Code");
			zipCode.setCellStyle(headerCellStyle);
			Cell city = headerRow.createCell(5);
			city.setCellValue("City");
			city.setCellStyle(headerCellStyle);
			Cell country = headerRow.createCell(6);
			country.setCellValue("Country");
			country.setCellStyle(headerCellStyle);
			
			FileOutputStream fileOut = new FileOutputStream("Bulk-Charge-Point-Template.xlsx");
			Download data = Download.getDownload();
		        workbook.write(fileOut);
		        data.setdata("data", workbook);
		        fileOut.close();

		        // Closing the workbook
		       
				//Download data= Download.getDownload();
				  HttpHeaders headers = new HttpHeaders();
			        headers.add("Content-Disposition", "attachment; filename=Bulk-Charge-Point-Template.xlsx");
			        headers.add("Content-Type","text/html");
			        
			        ByteArrayOutputStream   out = new ByteArrayOutputStream();
			        ByteArrayInputStream bis;
			        data.getData("data").write(out);;
			        bis=new ByteArrayInputStream(out.toByteArray());
			        InputStreamResource inputStreamResource =new InputStreamResource(bis);
			  	  bis.close();
			  	 workbook.close();
				if(inputStreamResource !=null) {
					return ResponseEntity
			                  .ok()
			                  .headers(headers)
			                  .body(inputStreamResource);
				
				}
				return ResponseEntity
		                .ok().body(null);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException("Internal server error");
		}
	}
	
}
