package com.webasto.commons;

import java.util.HashMap;
import java.util.Map;

public class ThreadLocalContext {

	public static final String USER_NAME = "USER_NAME";
	public static final String DATE_FORMAT = "DATE_FORMAT";
	
	
	private static final ThreadLocal<Map<String, Object>> local = new ThreadLocal<Map<String, Object>>();

	public static Object get(String key) {
		if (local.get() != null) {
			return local.get().get(key);
		}
		return null;
	}

	public static void set(String key, Object val) {
		Map<String, Object> dataMap = local.get();
		if (dataMap == null) {
			dataMap = new HashMap<String, Object>();
			local.set(dataMap);
		}
		local.get().put(key, val);
	}

	public static void destroy() {
		local.remove();
	}
}
