package com.webasto.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.TimeZone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.tool.hbm2ddl.Target;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.webasto.commons.ThreadLocalContext;

@Entity
@Table(name = "unknown_charge_point")
@NamedQueries(value = {@NamedQuery(name = "UnknownChargePoint.list", query = "SELECT u FROM UnknownChargePoint u"),
					   @NamedQuery(name = "UnknownChargePoint.count", query = "SELECT count(*) FROM UnknownChargePoint")})
public class UnknownChargePoint {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "charge_point_id")
	private String chargePointId;
	
	@Column(name = "ip_address")
	private String ipAddress;
	
	@Column(name = "created_time")
	private Date createdTime;
	
	@JsonFormat(pattern="MM-dd-yyyy HH:mm")
	@Column(name = "modified_time")
	private Date modifiedTime;
	
	@Column(name = "no_of_attempts", columnDefinition = "smallint(6) NOT NULL")
	private Short noOfAttempts;
	
	@Transient
	@Temporal(TemporalType.TIMESTAMP)
	private String lastModifiedTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLastModifiedTime() throws ParseException {
		//ThreadLocalContext.get(ThreadLocalContext.USER_NAME);
		//String timeZone = (String)ThreadLocalContext.get(ThreadLocalContext.TIME_ZONE);
		//System.out.println(timeZone);
		//SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm");
		//sdf.setTimeZone(TimeZone.getTimeZone(ZoneId.of("America/New_York")));
		//return sdf.format(modifiedTime);
		
		return lastModifiedTime;
	}

	/*public void setLastModifiedTime(String lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}*/

	public Short getNoOfAttempts() {
		return noOfAttempts;
	}

	public void setNoOfAttempts(Short noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	public String getChargePointId() {
		return chargePointId;
	}

	public void setChargePointId(String chargePointId) {
		this.chargePointId = chargePointId;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}
	
	

}
