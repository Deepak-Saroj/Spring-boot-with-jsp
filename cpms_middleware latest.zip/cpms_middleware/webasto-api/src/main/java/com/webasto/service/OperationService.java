package com.webasto.service;

public interface OperationService {

}
