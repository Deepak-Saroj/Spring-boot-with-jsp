package com.webasto.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.ChargePointOperation;
import com.webasto.model.ChargePointOperationLog;

public interface CPOperationControllerService {
	public ChargePointOperation addCPOperation(ChargePointOperation chargePointOperationData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public ChargePointOperationLog addCPOperationLog(ChargePointOperationLog chargePointOperationLogData) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public List<ChargePointOperation> getChargePointOperationList(String date) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
	public List<ChargePointOperationLog> getChargePointOperationLogsList(String date,String type) throws UniqueConstraintException, IllegalAccessException, InvocationTargetException, ServiceException, InvalidDataException;
}
