package com.webasto.controller;

import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.NotFoundException;
import com.webasto.commons.sql.exception.PersistenceException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.commons.sql.exception.UniqueConstraintException;
import com.webasto.model.OcppTag;
import com.webasto.model.OcppTagRequest;
import com.webasto.model.Response;
import com.webasto.model.ResponseList;
import com.webasto.service.OCPPTagService;

@RestController
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RequestMapping(value = "/ocpptag")
@CrossOrigin
public class OCPPTagController {

	private static final Logger LOG = LogManager.getLogger(OCPPTagController.class);

	@Autowired
	private OCPPTagService ocppTagService;
	
	
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ResponseEntity<Response> createOcppTag(@RequestBody @Valid OcppTagRequest ocppTag) throws UniqueConstraintException, ServiceException, InvalidDataException, IllegalAccessException, InvocationTargetException, ParseException{
		try {
			LOG.debug("STARTED : createOcppTag() of OCPPTagController class");		
			OcppTagRequest newOcppTag = ocppTagService.createOCPPTag(ocppTag); 
			Response response = new Response();
			response.setMessage("New ocpp tag is added successfully");
			LOG.debug("ENDED : createOcppTag() of OCPPTagController class");
			response.setData(newOcppTag);
			return ResponseEntity.ok(response);
		} catch (ServiceException e) {
			LOG.error(e);
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/search/{ocppTagId}",method = RequestMethod.GET)
	public ResponseEntity<OcppTagRequest> getOCPPTag(@PathVariable int ocppTagId) throws NotFoundException, ServiceException, InvalidDataException, IllegalAccessException, InvocationTargetException{
		try {
			LOG.debug("STARTED : getOCPPTag() of OCPPTagController class");
			OcppTagRequest ocppTag = ocppTagService.getOCPPTag(ocppTagId);
			LOG.debug("ENDED : getOCPPTag() of OCPPTagController class");
			return ResponseEntity.ok(ocppTag);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/search/parentIdTag",method = RequestMethod.GET)
	public ResponseEntity<ResponseList> getParentIdTagList() throws ServiceException{
		try {
			LOG.debug("STARTED : getOCPPTag() of OCPPTagController class");
			ResponseList response = new ResponseList();
			List parentIdTagList = ocppTagService.getParentIdTagList();
			response.setMessage("Parent Id tag list");
			response.setData(parentIdTagList);
			LOG.debug("ENDED : getOCPPTag() of getOCPPTag class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	/*@RequestMapping(value = "/search/parentIdTag/{id}",method = RequestMethod.GET)
	public ResponseEntity<ResponseList> getParentIdTagListBasedOnId(@PathVariable int id) throws ServiceException, NotFoundException{
		try {
			System.out.println("search");
			LOG.debug("STARTED : getOCPPTag() of OCPPTagController class");
			ResponseList response = new ResponseList();
			List parentIdTagList = ocppTagService.getParentIdTagListBasedOnId(id);
			response.setMessage("Parent Id tag list");
			response.setData(parentIdTagList);
			LOG.debug("ENDED : getOCPPTag() of getOCPPTag class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error("EXCEPTION : \"Internal server error \"Catch block executed of getOCPPTag() of OCPPTagController class" );
			throw new ServiceException("Internal server error");
		}
	}*/
	
	@RequestMapping(value = "/edit", method = RequestMethod.PUT)
	public ResponseEntity<Response> updateOCPPTag(@RequestBody @Valid OcppTagRequest ocppTag) throws InvalidDataException, NotFoundException, UniqueConstraintException, ServiceException, IllegalAccessException, InvocationTargetException, ParseException{
		try {
			LOG.debug("STARTED : updateOCPPTag() of OCPPTagController class");
			OcppTagRequest updatedOcppTag = ocppTagService.updateOCPPTag(ocppTag);
			Response response = new Response();
			response.setMessage("Ocpp tag updated successfully");
			response.setData(updatedOcppTag);
			LOG.debug("ENDED : updateOCPPTag() of OCPPTagController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/delete/{ocppTagId}",method = RequestMethod.DELETE)
	public ResponseEntity<Response> deleteOCPPTag(@PathVariable int ocppTagId) throws ServiceException, InvalidDataException, NotFoundException{
		try {
			LOG.debug("STARTED : deleteOCPPTag() of OCPPTagController class");
			Response response = ocppTagService.deleteOCPPTag(ocppTagId);
			LOG.debug("ENDED : deleteOCPPTag() of OCPPTagController class");
			return ResponseEntity.ok(response);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
		
	/*@RequestMapping(value = "/search",method = RequestMethod.GET)
	public ResponseEntity<List<OcppTag>> getOCPPTagList(@RequestParam int pageSize, @RequestParam int pageNumber) throws ServiceException{
		try {
			LOG.debug("STARTED : getOCPPTagList() of OCPPTagController class");
			List<OcppTag> ocppTagList = ocppTagService.getOCPPTagList(pageSize, pageNumber);
			LOG.debug("ENDED : getOCPPTagList() of OCPPTagController class");
			return ResponseEntity.ok(ocppTagList);
		} catch (ServiceException se) {
			LOG.error("EXCEPTION : \"Internal server error \"Catch block executed of getOCPPTagList() of OCPPTagController class" );
			throw new ServiceException("internal server error");
		}
	}*/
	
	@RequestMapping(value = "/search",method = RequestMethod.GET)
	public ResponseEntity<ResponseList> getOCPPTagList() throws ServiceException, IllegalAccessException, InvocationTargetException{
		try {
			LOG.debug("STARTED : getOCPPTagList() of OCPPTagController class");
			List ocppTagList = ocppTagService.getOCPPTagList();
			ResponseList responselist = new ResponseList();
			responselist.setMessage("Ocpp tag list");
			responselist.setData(ocppTagList);
			LOG.debug("ENDED : getOCPPTagList() of OCPPTagController class");
			return ResponseEntity.ok(responselist);
		} catch (ServiceException se) {
			LOG.error(se);
			throw new ServiceException("Internal server error");
		}
	}
		
}
