package com.webasto.model;


import javax.validation.constraints.Pattern;


public class PasswordUpdate {

	//@Pattern(regexp = "^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$")
	@Pattern(regexp ="^.{6,14}$", message = "Password length should lies between 6 to 14 characters")
	private String password;
	
	//@Pattern(regexp = "^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$")
	@Pattern(regexp ="^.{6,14}$", message = "Confirm Password length should lies between 6 to 14 characters")
	private String confirmPassword;
	
	@Pattern(regexp = "^$|\\w+([-+.]\\w+)*@(\\w+\\.com)", message = "Please enter a valid email format")
	private String email;
	
	private String token;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	
	
}
