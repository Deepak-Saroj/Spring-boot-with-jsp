package com.webasto.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "configuration")
@NamedQueries(value = {@NamedQuery(name = "Configuration.getByname", query ="SELECT c FROM Configuration c WHERE c.configName = 'HEARTBEAT_INTERVAL'"),
					   @NamedQuery(name = "Configuration.List", query ="SELECT c FROM Configuration c"),
					   @NamedQuery(name = "Configuration.Update", query ="UPDATE Configuration SET configValue =:configValue WHERE configName =:configName")})
public class Configuration {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "config_name")
	private String configName;
	
	@Column(name = "config_value")
	private String configValue;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "created_time")
	@CreationTimestamp
	private Date createdTime;
	
	@Column(name = "modified_time")
	@UpdateTimestamp
	private Date modifiedTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getConfigName() {
		return configName;
	}

	public void setConfigName(String configName) {
		this.configName = configName;
	}

	public String getConfigValue() {
		return configValue;
	}

	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public Date getModifiedTime() {
		return modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	@Override
	public String toString() {
		return "Configuration [id=" + id + ", configName=" + configName + ", configValue=" + configValue
				+ ", description=" + description + ", createdTime=" + createdTime + ", modifiedTime=" + modifiedTime
				+ "]";
	}
	
	

}
