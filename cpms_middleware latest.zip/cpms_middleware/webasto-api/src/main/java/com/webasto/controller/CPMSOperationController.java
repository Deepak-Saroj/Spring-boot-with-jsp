package com.webasto.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.webasto.commons.sql.exception.InvalidDataException;
import com.webasto.commons.sql.exception.ServiceException;
import com.webasto.model.CSOperation;
import com.webasto.model.CSOperationLog;
import com.webasto.model.ChargePointOperationLog;
import com.webasto.service.CSOperationControllerService;
import com.webasto.service.ChargePointService;

import io.vertx.core.http.HttpClient;
import io.vertx.core.http.WebSocket;
import io.vertx.core.http.WebSocketConnectOptions;

@CrossOrigin
@RestController
@RequestMapping(value = "/cs")
public class CPMSOperationController {

	private static final Logger LOG = LogManager.getLogger(CPMSOperationController.class);

	private Object[] response = null;

	private static WebSocket ws = null;
	
	@Autowired
	private CSOperationControllerService csOPService;
	
	@Autowired
	private ChargePointService chargePointService;
	
	@Autowired
	private WebSocketConnectOptions options;
	
	@Autowired
	private HttpClient client;

	@PostMapping(value = "/operations")
	public ResponseEntity<Object[]> performOperation(@RequestBody String data) throws JsonProcessingException {
		LOG.debug("STARTED: perform operation");
		System.out.println("start");
		String uuid="";
		try {
			ObjectMapper mapper = new ObjectMapper();
			JSONObject jsonObject = new JSONObject(data);
			this.response=null;
			System.out.println("Acctual request "+data);
			LOG.debug("Acctual request "+data);
			uuid=UUID.randomUUID().toString();
			String type = jsonObject.getString("type").toString();
			JSONObject payload = jsonObject.getJSONObject("payload");
			JSONArray cpList = jsonObject.getJSONArray("cplist");
			
			// perform validation that type and cplist is not empty, payload is valid with json schema
			String[] newPayload = { "2",uuid , cpList.toString(),type, payload.toString()};
			JSONArray arr = new JSONArray();
			arr.put(2);
			arr.put(uuid);
			arr.put(cpList);
			arr.put(type);
			arr.put(payload);
			
			if(type.equals("ChangeAvailability") || type.equals("RemoteStartTransaction") || type.equals("UnlockConnector") || type.equals("ReserveNow") || type.equals("GetCompositeScheduleRequest")){
				List<String> chargePointList = new ArrayList<String>();
				LOG.debug("type "+type);
				if(cpList != null) {
					LOG.debug("cpList "+cpList);
					for(int i = 0; i < cpList.length(); i++) {
						chargePointList.add(cpList.getString(i));
					}
				}
				int connectorId = payload.getInt("connectorId");
				if(connectorId > 0){
					LOG.debug("connectorId "+connectorId);
					List<String> unavailableList = chargePointService.getConnector(chargePointList, connectorId);
					if(unavailableList.size() > 0){
						String message = "Selected connectorId is not available for these charge point ids ";
						for(String cp : unavailableList){
							message = message + cp+",";
						}
						String [] response = {"","","",message};
						this.response = response;
						LOG.debug("response "+response);
						return ResponseEntity.ok(this.response);
					}
				}	
			}      
			CSOperation cpo=new CSOperation();
			cpo.setId(uuid);
			cpo.setName(type);
			csOPService.addCSOperation(cpo);
		    
		    CSOperationLog cpol=new CSOperationLog();
		    cpol.setId(uuid);
		    cpol.setType(2);
		    cpol.setMsg(arr.toString());
		    csOPService.addCSOperationLog(cpol);
			

			String webSocketMsg = arr.toString();
			System.out.println("Web Socket Msg"+webSocketMsg);
			LOG.debug("Web Socket Msg"+webSocketMsg);

			if(ws==null){
				LOG.debug("ws client : 1" +ws);
				
				ws=	this.getWebSocketClient();
				//	LOG.debug("handler "+ handler.toString());

					ws.textMessageHandler(textHandler -> {

						System.out.println("Response " + textHandler.toString());
						LOG.debug("Response " + textHandler.toString());
						try {
							this.response = mapper.readValue(textHandler.toString(), Object[].class);
							Object msgtype = this.response[0];
							Object msgUUId = this.response[1];
							Object msg = textHandler.toString();
							LOG.debug("msg " + textHandler.toString());
							 CSOperationLog newcpol=new CSOperationLog();
							 newcpol.setId(msgUUId.toString());
							 newcpol.setType(Integer.parseInt(msgtype.toString()));
							 newcpol.setMsg(msg.toString());
							 csOPService.addCSOperationLog(newcpol);
						} catch (Exception e) {
							LOG.error(e);
							e.printStackTrace();
						}
					});
					ws.writeFinalTextFrame(webSocketMsg);
				
		
			}else if(!ws.isClosed()){
				LOG.debug("ws client : 2" +ws);
				//ws.isClosed();
				ws.writeFinalTextFrame(webSocketMsg);
				ws.textMessageHandler(textHandler -> {
					LOG.debug("Response " + textHandler.toString());
					try {
						this.response = mapper.readValue(textHandler.toString(), Object[].class);
						Object msgtype = this.response[0];
						Object msgUUId = this.response[1];
						Object msg = textHandler.toString();				
						CSOperationLog newcpol=new CSOperationLog();
						newcpol.setId(msgUUId.toString());
						newcpol.setType(Integer.parseInt(msgtype.toString()));
						newcpol.setMsg(msg.toString());
						csOPService.addCSOperationLog(newcpol);
						Object id = this.response[0];
						LOG.debug("response id " + id.toString());
					} catch (Exception e) {
						LOG.error(e);
						e.printStackTrace();
					}
				});
			}else{
				ws=	this.getWebSocketClient();
			}
			if (this.response== null) {
				String[] responseData = { "3", uuid,"Request is Processed Successfully"};
				LOG.debug("responseData " + responseData);
				this.response= responseData;
			}
		}catch(Exception e) {
			LOG.error(e);
			e.printStackTrace();
			String[] responseData = { "4", uuid,"Could not able to process the Request.Please Contact Adminstrator","Could not able to process the Request.Please Contact Adminstrator"};
			this.response= responseData;
		}
		return ResponseEntity.ok(this.response);
	}

	@RequestMapping(value = "/operations/logList/{date}", method = RequestMethod.GET)
	public ResponseEntity<List<CSOperation>> getChargePointOperationsList(@PathVariable String date) throws ServiceException{
		try {
			LOG.debug("STARTED : getChargePointOperationsList() of CPMSOperationController class");
			List<CSOperation> cslist = csOPService.getCSOperationList(date);
			LOG.debug("ENDED : getChargePointOperationsList() of CPMSOperationController class");
			return ResponseEntity.ok(cslist);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
			throw new ServiceException("Internal server error");
		}
	}

	@RequestMapping(value = "/operations/logList/{date}/{type}", method = RequestMethod.GET)
	public ResponseEntity<List<CSOperationLog>> getChargePointOperationsLogsList(@PathVariable String date,@PathVariable String type) throws ServiceException{
		try {
			LOG.debug("STARTED : getChargePointOperationsLogsList() of CPMSOperationController class");
			List<CSOperationLog> cslist = csOPService.getCSOperationLogsList(date,type);
			LOG.debug("ENDED : CPMSOperationController() of CPMSOperationController class");
			return ResponseEntity.ok(cslist);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/operations/log/{date}", method = RequestMethod.GET)
	public ResponseEntity<List<CSOperationLog>> getCSOperationsLogsListByDate(@PathVariable String date) throws ServiceException{
		try {
			LOG.debug("STARTED : getCSOperationsLogsListByDate() of CPMSOperationController class");
			List<CSOperationLog> cslist = csOPService.getList(date);
			LOG.debug("ENDED : getCSOperationsLogsListByDate() of CPMSOperationController class");
			return ResponseEntity.ok(cslist);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
			throw new ServiceException("Internal server error");
		}
	}
	
	/*@RequestMapping(value = "/operations/log/search/{id}", method = RequestMethod.GET)
	public ResponseEntity<List<CSOperationLog>> getCSOperationsLogsListById(@PathVariable String id) throws ServiceException{
		try {
			LOG.debug("STARTED : getChargPoint Operations");
			List<CSOperationLog> cslist = csOPService.getOperationLogs(id);
			LOG.debug("ENDED : getChargingProfile() of ChargePointController class");
			return ResponseEntity.ok(cslist);
		} catch (Exception e) {
			e.printStackTrace();

			LOG.error("EXCEPTION : \"Internal server error \"Catch block executed of getChargingProfile() of ChargePointController class" );
			throw new ServiceException("Internal server error");
		}
	}*/
	
	@RequestMapping(value = "/operations/log/search/{date}", method = RequestMethod.GET)
	public ResponseEntity<List<CSOperation>> getCSOperationsLogsListsearch(@PathVariable String date) throws ServiceException{
		try {
			LOG.debug("STARTED : getCSOperationsLogsListsearch() of CPMSOperationController class");
			List<CSOperation> cslist = csOPService.getAllOperations(date);
			LOG.debug("ENDED : getCSOperationsLogsListsearch() of CPMSOperationController class");
			return ResponseEntity.ok(cslist);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
			throw new ServiceException("Internal server error");
		}
	}
	
	@RequestMapping(value = "/operations/log/search/pagination/{date}", method = RequestMethod.GET)
	public ResponseEntity<List<CSOperation>> getCSOperationsLogsListPaginationSearch(@PathVariable String date) throws ServiceException{
		try {
			LOG.debug("STARTED : getCSOperationsLogsListPaginationSearch() of CPMSOperationController class");
			List<CSOperation> cslist = csOPService.getAllOperationsPagination(date, 10, 1);
			LOG.debug("ENDED : getCSOperationsLogsListPaginationSearch() of CPMSOperationController class");
			return ResponseEntity.ok(cslist);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
			throw new ServiceException("Internal server error");
		}
	}
	private WebSocket getWebSocketClient(){
		client.webSocket(options, handler -> {
			LOG.debug("handler "+ handler.toString());
			ws = handler.result();		
			LOG.debug("successed "+handler.succeeded());		
		});
		return ws;
	}
	
}