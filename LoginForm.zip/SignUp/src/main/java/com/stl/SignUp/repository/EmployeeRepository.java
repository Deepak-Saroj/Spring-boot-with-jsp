package com.stl.SignUp.repository;

import org.springframework.data.repository.CrudRepository;

import com.stl.SignUp.entitny.Employee;

public interface EmployeeRepository extends  CrudRepository<Employee, Integer>{

}
