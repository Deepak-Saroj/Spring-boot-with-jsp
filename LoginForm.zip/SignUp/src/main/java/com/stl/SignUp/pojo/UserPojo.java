package com.stl.SignUp.pojo;

import lombok.Data;

@Data
public class UserPojo {
	private String username;
	private String password;

}
