package com.stl.SignUp.service;
import com.stl.SignUp.entitny.Employee;
import com.stl.SignUp.entitny.User;

public interface UserService {
	public User login(String userename, String password);
	public Iterable<Employee> getAllEmployee();
	public Employee addEmployee(Employee emp);
}
