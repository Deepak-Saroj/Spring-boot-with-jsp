package com.stl.SignUp.repository;

import org.springframework.data.repository.CrudRepository;

import com.stl.SignUp.entitny.User;

public interface UserRepository extends  CrudRepository<User, Integer>{
	public User findByUsernameAndPassword(String userename, String password);

}
