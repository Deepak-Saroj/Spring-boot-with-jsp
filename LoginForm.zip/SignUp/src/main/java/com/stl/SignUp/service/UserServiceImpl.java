package com.stl.SignUp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stl.SignUp.entitny.Employee;
import com.stl.SignUp.entitny.User;
import com.stl.SignUp.repository.EmployeeRepository;
import com.stl.SignUp.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userRepository;
	@Autowired
	EmployeeRepository empRepository;

	@Override
	public User login(String userename, String password) {
		
		return userRepository.findByUsernameAndPassword(userename, password);
	}

	@Override
	public Iterable<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return empRepository.findAll();
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return empRepository.save(emp);
	}

}
