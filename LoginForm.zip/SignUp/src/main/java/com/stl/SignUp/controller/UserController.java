package com.stl.SignUp.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.stl.SignUp.entitny.Employee;
import com.stl.SignUp.entitny.User;
import com.stl.SignUp.pojo.UserPojo;
import com.stl.SignUp.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;

	@GetMapping("/")
	public String HomePage() {
		return "Home";
	}
	@GetMapping("/Login")
	public String LoginPage(Model model) {
		
		  UserPojo user=new UserPojo(); model.addAttribute("user", user);
		 
		return "Login";
	}
	
	  @GetMapping("/register_form")
	  public String addUser(Model model) 
	  { 
			
			  Employee employee=new Employee(); 
			  model.addAttribute("employee", employee);
			  
		  return  "register_form"; 
	}
	  @GetMapping("/Employee_Details")
	  public ModelAndView employeeDetails() 
	  { 
			
			
			ModelAndView mdv=new ModelAndView();
			List<Employee> result=(List<Employee>) userService.getAllEmployee();
			mdv.addObject("employees", result);
			mdv.setViewName("Employee_Details");
			  
		  return  mdv;
	}
	 
	@PostMapping("/register") 
	public String addUser(@ModelAttribute("employee") Employee employee) 
	{ 
		Employee emp=userService.addEmployee(employee);
		if(emp!=null)
		return "reg_success";
		else 
			return "reg_failed";
	}

	
	@PostMapping("/login") 
	public String login(@ModelAttribute("user") UserPojo user) 
	{ 
		User result=userService.login(user.getUsername(), user.getPassword());
		if(result!=null)
		return "success";
		else return "Failed";
		}

}
